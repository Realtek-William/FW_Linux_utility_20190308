#include "stdafx.h"
#include "CpRsFuncBase.h"
#include <fstream>
#include <vector>
using namespace std;

#define LINE_LENGTH 1024

void Trim(string &s)
{
    string::size_type index = 0;
    if(!s.empty())
    {
        index = s.find(' ',index);
        while(index != (string::npos))
        {
            s.erase(index, 1);
        }
    }

}

UINT CpRsGetPrivateProfileInt(CHAR *pAppName, CHAR *pkeyName, INT nDefault, CHAR *pFileName)
{
    CHAR buf[LINE_LENGTH] ={""};
    UINT unValue = nDefault;

    if(CpRsGetPrivateProfileString(pAppName, pkeyName, (CHAR *)(""), buf, _MAX_PATH, pFileName))
    {
        unValue = (UINT)strtol(buf, NULL, 0);
    }

    return unValue;
}

INT CpRsGetPrivateProfileString(CHAR *pAppName, CHAR *pkeyName, CHAR *pDefault, CHAR * pcszBuff, DWORD nSize, CHAR *pFileName)
{
    string strTmp = "", strApp, strKey;
    CHAR line[LINE_LENGTH];
    string line2;
    string::size_type return_of_find;
    BOOL bfound = false;

    strApp = "[";
    strApp += pAppName;
    strApp +="]";

    strKey = pkeyName;

    ifstream mystream(pFileName, ios::in);

    if(!mystream.is_open())
    {
        cout << "Error " << endl;
        return 0;
    }

    while(mystream.getline(line, LINE_LENGTH) && !bfound)
    {
        line2 = line;
        Trim(line2);
        if(strApp.compare(line2) != 0)
        {
            continue;
        }

        while(mystream.getline(line, LINE_LENGTH) && !bfound)
        {
            line2 = line;
            string equal_flag = "=";

            return_of_find = line2.find(equal_flag);
            if(string::npos == return_of_find)
            {
                return 0;
            }
            strTmp = line2.substr(0, return_of_find);
            if(strKey.compare(strTmp) != 0)
            {
                continue;
            }
            return_of_find = line2.rfind("="); 
            strTmp = line2.substr(return_of_find + 1);
            strcpy(pcszBuff, strTmp.c_str());
            bfound = true;
        }
    }
    mystream.close();
    if(bfound)
    {
        return strTmp.length();
    }
    else
    {
        strcpy(pcszBuff, pDefault);
        return 0;
    }
}
BOOL CpRsWritePrivateProfileString(CHAR *pAppName, CHAR * pKeyName, CHAR * pString, CHAR * pFileName)
{
    CHAR line[LINE_LENGTH];
    string line2, strTmp, strApp, strKey;
    string::size_type return_of_find;
    vector<string> vecLine; 
    UINT i = 0;
    BOOL bFindApp = false, bKeyFind = false;
    streampos pos;

    fstream fIn(pFileName, ios::in);
    strApp = "[";
    strApp += pAppName;
    strApp +="]";

    strKey = pKeyName;
    vecLine.clear();
    if(fIn.is_open())
    {
        while(fIn.getline(line, LINE_LENGTH))
        {
            vecLine.push_back(line);
        }
        fIn.close();
    }

    fstream fOut(pFileName, ios::out | ios::trunc);
    if(!(fOut.is_open()))
    {
        cout << "Open file error " << endl;
        return false;
    }
    while((i < vecLine.size()) && (vecLine.size() != 0))
    {
        line2 = vecLine[i];
        i++;
        Trim(line2);
        if(strApp.compare(line2) != 0)
        {
            fOut << line2.c_str() << endl;
            continue;
        }
        fOut << line2.c_str() << endl;
        bFindApp = true;
        while(i < vecLine.size())
        {
            line2 = vecLine[i];
            i++;
            Trim(line2);
            string equal_flag = "=";
            return_of_find = line2.find(equal_flag);
            if(string::npos == return_of_find)
            {
                if(!bKeyFind)
                {
                    bKeyFind = true;
                    strTmp = pKeyName;
                    strTmp += "=";
                    strTmp += pString;
                    fOut << strTmp.c_str() << endl;
                }
                fOut << line2.c_str() << endl;
                break;
            }
            strTmp = line2.substr(0, return_of_find);
            if(strKey.compare(strTmp) != 0)
            {
                fOut << line2.c_str() << endl;
                continue;
            }
            bKeyFind = true;
            return_of_find = line2.rfind("=");
            strTmp = line2.substr(0, return_of_find + 1);
            strTmp += pString;
            fOut << strTmp.c_str() << endl;
            break;
        }
    }
    if(!bFindApp)
    {
        fOut.seekp(0, ios::end);
        strTmp = "[";
        strTmp += pAppName;
        strTmp += "]\n";
        strTmp += pKeyName;
        strTmp += "=";
        strTmp += pString;
        fOut << strTmp.c_str() << endl;
    }
    else
    {
        if(!bKeyFind)
        {
            strTmp = pKeyName;
            strTmp += "=";
            strTmp += pString;
            fOut << strTmp.c_str() << endl;
        }
    }
    fOut.close();
    return true;
}

BOOL CpRsSaveAnsiFile(CCpRsString strFile, CCpRsString strBuffer, DWORD ulLength)
{
#ifdef UNICODE
    FILE *file = NULL;
    DWORD ulSaveLength = 0;
    string strFileTmp(strFile.begin(), strFile.end());
    string strBufferTmp(strBuffer.begin(), strBuffer.end());
    
    ulSaveLength = strBufferTmp.length();
    ulLength = ulSaveLength;
    file = fopen(strFileTmp.data(), "w+");
    if(file == NULL)
    {
        //printf("Can not open %s!\n", strFile);
        return FALSE;
    }

    fwrite(strBufferTmp.data(), sizeof(CHAR), ulSaveLength, file);
    fclose(file);

    return TRUE;
#else
    FILE *file = NULL;
    DWORD ulSaveLength = 0;

    if(ulLength == 0)
    {
        ulSaveLength = strBuffer.length();
    }
    else
    {
        ulSaveLength = ulLength;
    }
    file = fopen(strFile.data(), "w+");
    if(file == NULL)
    {
        //printf("Can not open %s!\n", strFile);
        return FALSE;
    }

    fwrite(strBuffer.data(), sizeof(CHAR), ulSaveLength, file);
    fclose(file);

    return TRUE;
#endif
}
