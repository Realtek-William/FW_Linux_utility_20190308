#include "stdafx.h"
#include "CpRsString.h"
#include <vector>

CCpRsString operator+ (const CCpRsString& lhs, const CCpRsString& rhs)
{
    CpRsStringBase strTmp;
    strTmp = ((CpRsStringBase)lhs + (CpRsStringBase)rhs);
    return (CCpRsString)strTmp.data();
}

CCpRsString operator+ (const CCpRsString& lhs, const TCHAR* rhs)
{
    CpRsStringBase strTmp;
    strTmp = ((CpRsStringBase)lhs + rhs);
    return (CCpRsString)strTmp.data();
}
CCpRsString operator+ (const TCHAR* lhs, const CCpRsString& rhs)
{
    CpRsStringBase strTmp;
    strTmp = ((CpRsStringBase)rhs + lhs);
    return (CCpRsString)strTmp.data();
}
CCpRsString operator+ (const CCpRsString& lhs, TCHAR rhs)
{
    CpRsStringBase strTmp;
    strTmp = ((CpRsStringBase)lhs + rhs);
    return (CCpRsString)strTmp.data();
}
CCpRsString operator+ (TCHAR lhs, const CCpRsString& rhs)
{
    CpRsStringBase strTmp;
    strTmp = ((CpRsStringBase)rhs + lhs);
    return (CCpRsString)strTmp.data();
}

bool operator== (const CCpRsString& lhs, const CCpRsString& rhs)
{
    return (CpRsStringBase(lhs) == CpRsStringBase(rhs));
}
bool operator== (const TCHAR* lhs, const CCpRsString& rhs)
{
    return (CpRsStringBase(lhs) == CpRsStringBase(rhs));
}
bool operator== (const CCpRsString& lhs, const TCHAR* rhs)
{
    return (CpRsStringBase(lhs) == CpRsStringBase(rhs));
}
bool operator!= (const CCpRsString& lhs, const CCpRsString& rhs)
{
    return (CpRsStringBase(lhs) != CpRsStringBase(rhs));
}
bool operator!= (const TCHAR* lhs, const CCpRsString& rhs)
{
    return (CpRsStringBase(lhs) != CpRsStringBase(rhs));
}
bool operator!= (const CCpRsString& lhs, const TCHAR* rhs)
{
    return (CpRsStringBase(lhs) != CpRsStringBase(rhs));
}
bool operator<  (const CCpRsString& lhs, const CCpRsString& rhs)
{
    return (CpRsStringBase(lhs) < CpRsStringBase(rhs));
}
bool operator<  (const TCHAR* lhs, const CCpRsString& rhs)
{
    return (CpRsStringBase(lhs) < CpRsStringBase(rhs));
}
bool operator<  (const CCpRsString& lhs, const TCHAR* rhs)
{
    return (CpRsStringBase(lhs) < CpRsStringBase(rhs));
}
bool operator<= (const CCpRsString& lhs, const CCpRsString& rhs)
{
    return (CpRsStringBase(lhs) <= CpRsStringBase(rhs));
}
bool operator<= (const TCHAR*   lhs, const CCpRsString& rhs)
{
    return (CpRsStringBase(lhs) <= CpRsStringBase(rhs));
}
bool operator<= (const CCpRsString& lhs, const TCHAR*   rhs)
{
    return (CpRsStringBase(lhs) <= CpRsStringBase(rhs));
}
bool operator>  (const CCpRsString& lhs, const CCpRsString& rhs)
{
    return (CpRsStringBase(lhs) > CpRsStringBase(rhs));
}
bool operator>  (const TCHAR*   lhs, const CCpRsString& rhs)
{
    return (CpRsStringBase(lhs) > CpRsStringBase(rhs));
}
bool operator>  (const CCpRsString& lhs, const TCHAR*   rhs)
{
    return (CpRsStringBase(lhs) > CpRsStringBase(rhs));
}
bool operator>= (const CCpRsString& lhs, const CCpRsString& rhs)
{
    return (CpRsStringBase(lhs) >= CpRsStringBase(rhs));
}
bool operator>= (const TCHAR*   lhs, const CCpRsString& rhs)
{
    return (CpRsStringBase(lhs) >= CpRsStringBase(rhs));
}
bool operator>= (const CCpRsString& lhs, const TCHAR*   rhs)
{
    return (CpRsStringBase(lhs) >= CpRsStringBase(rhs));
}

istream& operator >> (istream& is, CCpRsString& str)
{
    CHAR s[1024];
    is >> s;
    string strTmp = s;
#ifdef UNICODE
    wstring strTarget(strTmp.begin(), strTmp.end());
    str = strTarget;
#else
    str = s;
#endif
    return is;
}

ostream& operator<< (ostream& os, const CCpRsString& str)
{
    os << str.data();
    return os;
}

CCpRsString::CCpRsString()
{
}

CCpRsString::CCpRsString(const CCpRsString& str)
    :CpRsStringBase(str)
{
}

CCpRsString::CCpRsString(const CCpRsString& str, size_t pos, size_t len)
    :CpRsStringBase(str, pos, len)
{
}
 
CCpRsString::CCpRsString(const TCHAR* s)
    :CpRsStringBase(s)
{
}
CCpRsString::CCpRsString(const TCHAR* s, size_t n)
    :CpRsStringBase(s, n)
{
}
 
CCpRsString::CCpRsString(size_t n, TCHAR c)
    : CpRsStringBase(n, c)
{
}
 
CCpRsString::~CCpRsString()
{
}

CCpRsString& CCpRsString::operator= (const CCpRsString& str)
{
    if(this != &str)
    {
        CpRsStringBase::operator=(str);
    }
    return *this;

}
CCpRsString& CCpRsString::operator= (const TCHAR* s)
{
    CpRsStringBase::operator=(s);
    return *this;
}
CCpRsString& CCpRsString::operator= (TCHAR c)
{
    CpRsStringBase::operator=(c);
    return *this;
}
CCpRsString& CCpRsString::operator= (const CpRsStringBase& str)
{
    this->assign(str);
    return *this;
}

void CCpRsString::Format(const TCHAR *pszFmt, ...)
{
    va_list args, argsTmp;
    va_start(args, pszFmt);
    va_start(argsTmp, pszFmt);
    // using argsTmp to get Length first for 
    // Linux can't use vsnprintf twice with the same args
    int nLength = CpRsnprintf(0, 0, pszFmt, argsTmp);
    nLength += 1;
    std::vector<TCHAR> vectorChars(nLength);
    CpRsnprintf(vectorChars.data(), nLength, pszFmt, args);
    this->assign(vectorChars.data());
    va_end(args);
}

CCpRsString CCpRsString::Left(INT nCount) const
{
    CCpRsString strTmp;
    strTmp = this->substr(0, nCount);
     return strTmp;
}
