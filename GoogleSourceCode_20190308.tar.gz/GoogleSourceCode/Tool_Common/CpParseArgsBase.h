#pragma once
#ifndef _CPISP_PARSE_ARGS_BASE_H
#define  _CPISP_PARSE_ARGS_BASE_H
#include "CpRsFuncBase.h"
#include "CpArgDefine.h"
#include <fstream>

#define COMMAND_CP_DIGITAL_SIGN_FW                          0x01
#define COMMAND_CP_DIGITAL_SIGN_SIGNATURE                   0x02
#define COMMAND_CP_DIGITAL_SIGN_RTK_KEY_PAIR                0x03
#define COMMAND_CP_DIGITAL_SIGN_PUBLIC_KEY                  0x04
#define COMMAND_CP_DIGITAL_SIGN_PRIVATE_KEY                 0x05
#define COMMAND_CP_DIGITAL_SIGN_SUB_CERT                    0x06

#define COMMAND_CP_ISPTOOL_COMMUNICATION                    0x0F
#define COMMAND_CP_ISPTOOL_START_BANK                       0x10
#define COMMAND_CP_ISPTOOL_FW_1                             0x11
#define COMMAND_CP_ISPTOOL_START_BANK_1                     0x12
#define COMMAND_CP_ISPTOOL_FW_2                             0x13
#define COMMAND_CP_ISPTOOL_START_BANK_2                     0x14
#define COMMAND_CP_ISPTOOL_FW_3                             0x15
#define COMMAND_CP_ISPTOOL_START_BANK_3                     0x16
#define COMMAND_CP_ISPTOOL_FW_4                             0x17
#define COMMAND_CP_ISPTOOL_START_BANK_4                     0x18
#define COMMAND_CP_ISPTOOL_FW_5                             0x19
#define COMMAND_CP_ISPTOOL_START_BANK_5                     0x1A
#define COMMAND_CP_ISPTOOL_FW_6                             0x1B
#define COMMAND_CP_ISPTOOL_START_BANK_6                     0x1C
#define COMMAND_CP_ISPTOOL_FW_7                             0x1D
#define COMMAND_CP_ISPTOOL_START_BANK_7                     0x1E
#define COMMAND_CP_ISPTOOL_FW_8                             0x1F
#define COMMAND_CP_ISPTOOL_START_BANK_8                     0x20
#define COMMAND_CP_ISPTOOL_FW_9                             0x21
#define COMMAND_CP_ISPTOOL_START_BANK_9                     0x22

#define COMMAND_CP_ISPTOOL_ISP_SLAVE_ADDR                   0x23
#define COMMAND_CP_ISPTOOL_READ_VERSION                     0x24
#define COMMAND_CP_ISPTOOL_USER_FLAG_ADDR                   0x25

#define CP_ISPTOOL_VER_FROM_REG                     0x00000001
#define CP_ISPTOOL_VER_FROM_DDCCI                   0x00000002
#define CP_ISPTOOL_VER_FROM_FLASH                   0x00000004

#define CP_ISPTOOL_FUNC_ERASE                       0x00000001
#define CP_ISPTOOL_FUNC_ISP_NORMAL                  0x00000002
#define CP_ISPTOOL_FUNC_ISP_NORMAL_HW_SIGN          0x00000004
#define CP_ISPTOOL_FUNC_ISP_NORMAL_SW_SIGN          0x00000008
#define CP_ISPTOOL_FUNC_ISP_FW_PARTITION            0x00000010
#define CP_ISPTOOL_FUNC_ISP_FW_PARTITION_HW_SIGN    0x00000020
#define CP_ISPTOOL_FUNC_ISP_FW_PARTITION_SW_SIGN    0x00000040
#define CP_ISPTOOL_FUNC_ISP_DIFFER_BANK             0x00000080
#define CP_ISPTOOL_FUNC_ISP_DIFFER_BANK_HW_SIGN     0x00000100
#define CP_ISPTOOL_FUNC_ISP_DIFFER_BANK_SW_SIGN     0x00000200
#define CP_ISPTOOL_FUNC_ISP_COPY_BANK               0x00000400
#define CP_ISPTOOL_FUNC_ISP_COPY_BANK_HW_SIGN       0x00000800
#define CP_ISPTOOL_FUNC_ISP_COPY_BANK_SW_SIGN       0x00001000

typedef struct STRUCT_COMMAND_FW_BANK
{
    INT nFwBank;
    string strFwPath;

    STRUCT_COMMAND_FW_BANK() : nFwBank(-1), strFwPath("")
    {
    }
}STRUCT_COMMAND_FW_BANK;

typedef struct STRUCT_COMMAND_ARGS_SETTING 
{
    int nFunc;
    string strSlave;
    string strCommID;
    bool bReadVer;
    int nVerType;
    string strUserFlagAddr;

    STRUCT_COMMAND_ARGS_SETTING():nFunc(0), strSlave(""), strCommID(""),
        bReadVer(false), nVerType(0), strUserFlagAddr("")
    {}
}STRUCT_COMMAND_ARGS_SETTING;

class CCpParseArgsBase
{
public:
    CCpParseArgsBase();
    ~CCpParseArgsBase();

    string GetCurrentDir() { return m_strCurDir; }
    void SetCurrentDir(string strPath) { m_strCurDir = strPath; }

    virtual int ParseArgs(int argc, char *const *argv) = 0;

    BOOL JudgeFunctionType(INT nFuncType);
    BOOL InsertCommandFwFile(DWORD ulIndex, string strFile);
    BOOL InsertCommandStartBank(DWORD ulIndex, string strStBank);
    BOOL GetFwBankCount(string &strFile, DWORD &ulBankCnt);
    string GetFileFullPath(string strArg);
    BOOL GetSlaveAddress(string strArg, INT &nAutoSlave, BYTE &ucSlaveAddr);
    void GetFunctionType(int nFuncType, ENUM_ISP_FUNCTION_TYPE &enumFuncType);
    BOOL JudgeFwMap(std::map<DWORD, STRUCT_FW_BANK_SETTING, sortAscending<DWORD> > &mapFw);
    BOOL JudgeArgument(STRUCT_COMMAND_ARGS_SETTING stArgSetting);
    BOOL GetCommID(string strArg, STRUCT_ENUM_COMM_ID &enumCommID);
    BOOL GetArgsIntValue(string strArg, INT &nValue);
    void GetReadVerType(int nType, ENUM_READ_VER_TYPE &enumType);

public:
    STRUCT_CP_ISP_TOOL_COMMAND m_stCmd;

private:
    string m_strCurDir;
    std::map<DWORD, STRUCT_COMMAND_FW_BANK, sortAscending<DWORD> > m_mapCmdFw;
};



// #define COMMAND_CP_ISPTOOL_ISP_BEFORE_ACON          0x102
// #define COMMAND_CP_ISPTOOL_ISP_BEFORE_ACON_TIME     0x103
// #define COMMAND_CP_ISPTOOL_RESET_MCU_AFTER_ISP      0x104
// #define COMMAND_CP_ISPTOOL_I2C_SPEED                0x105
// #define COMMAND_CP_ISPTOOL_SAVE_RESULT              0x106
// #define COMMAND_CP_ISPTOOL_SAVE_DEBUG_LOG           0x107
// #define COMMAND_CP_ISPTOOL_SAVE_PROGRESS            0x108
// #define COMMAND_CP_ISPTOOL_DELAY_TIME_AFTER_ISP     0x109
// #define COMMAND_CP_ISPTOOL_FLASH_TYPE               0x10A
// #define COMMAND_CP_ISPTOOL_FLASH_MISMATCH_OPRATE    0x10B
// #define COMMAND_CP_ISPTOOL_ERASE_TYPE               0x10C
// #define COMMAND_CP_ISPTOOL_BOOT_FLAG_ADDR           0x10D
// #define COMMAND_CP_ISPTOOL_BOOT_FLAG_VAL            0x10E
// #define COMMAND_CP_ISPTOOL_QISDA_FACTORY            0x10F
// 
// 
// #define COMMAND_CP_ISPTOOL_REV0_BANK                0x200
// #define COMMAND_CP_ISPTOOL_REV0_TYPE                0x201
// #define COMMAND_CP_ISPTOOL_REV0_START_ADDR          0x202
// #define COMMAND_CP_ISPTOOL_REV0_LENGTH              0x203
// #define COMMAND_CP_ISPTOOL_REV0_SECTOR_COUNT        0x204
// #define COMMAND_CP_ISPTOOL_REV0_AUTO_SECTOR         0x205
// 
// #define COMMAND_CP_ISPTOOL_REV1_BANK                0x206
// #define COMMAND_CP_ISPTOOL_REV1_TYPE                0x207
// #define COMMAND_CP_ISPTOOL_REV1_START_ADDR          0x208
// #define COMMAND_CP_ISPTOOL_REV1_LENGTH              0x209
// #define COMMAND_CP_ISPTOOL_REV1_SECTOR_COUNT        0x20A
// #define COMMAND_CP_ISPTOOL_REV1_AUTO_SECTOR         0x20B

// { "acon", required_argument, NULL, },
// {"acontime", required_argument, NULL,},
// {"resetmcu", required_argument, NULL,},
// {"speed", required_argument, NULL,},
// {"saveret", required_argument, NULL,},
// {"savelog", required_argument, NULL,},
// {"saveprog", required_argument, NULL,},
// {"delay", required_argument, NULL,},
// {"flash", required_argument, NULL,},
// {"mismatch", required_argument, NULL,},
// {"erase", required_argument, NULL,},
// {"rev0bank", required_argument, NULL,},
// {"rev0type", required_argument, NULL,},
// {"rev0addrst", required_argument, NULL,},
// {"rev0len", required_argument, NULL,},
// {"rev0sector", required_argument, NULL,},
// {"rev0auto", required_argument, NULL,},
// 
// {"bootflagaddr", required_argument, NULL,},
// {"bootflagval", required_argument, NULL,},
// 
// {"qisdafactory", required_argument, NULL,},

#endif