#ifndef _RSDATATYPE_H_
#define _RSDATATYPE_H_
#include <iostream>
#include <string.h>
using namespace std;

#ifndef BYTE
typedef unsigned char BYTE;
typedef BYTE       *LPBYTE;
#endif

#ifndef CHAR
typedef  char CHAR;
#endif
#ifndef WCHAR
typedef wchar_t WCHAR;
#endif

#ifndef WORD
typedef unsigned short WORD;
typedef WORD        *LPWORD;
#endif

#ifndef DWORD
#if __WORDSIZE == 64 
typedef unsigned int DWORD;
#else
typedef unsigned long DWORD;
#endif
#endif
#ifndef LPDWORD
typedef DWORD * LPDWORD;
#endif

#ifndef FLOAT
typedef float FLOAT;
#endif

#ifndef BOOL
typedef int BOOL;
#endif

#ifndef LONG
typedef long LONG;
#endif


#ifndef INT
typedef int                 INT;
#endif

#ifndef UINT
typedef unsigned int        UINT;
#endif

#ifndef VOID
typedef void        VOID;
#endif


#ifndef _MAX_PATH
#define  _MAX_PATH 260
#endif


#ifndef CONST
#define CONST               const
#endif

#ifndef FALSE
#define FALSE               0
#endif

#ifndef TRUE
#define TRUE                1
#endif

#define UNUSEDED_PARAMETER(x) do { x = x; } while(0)

#ifdef  UNICODE
#ifndef _TCHAR_DEFINED
typedef wchar_t TCHAR;
typedef WCHAR TCHAR, *PTCHAR;
typedef WCHAR TBYTE, *PTBYTE;
typedef const TCHAR * LPCTSTR;
#define _TCHAR_DEFINED
#endif
#ifndef _tcscpy_s
#define _tcscpy_s wcscpy_s
#endif
#else 
#ifndef _TCHAR_DEFINED
typedef char TCHAR;
typedef const TCHAR * LPCTSTR;
#define _TCHAR_DEFINED
#endif
#ifndef _tcscpy_s
#define _tcscpy_s strcpy
#endif
#endif //UNICODE



#ifdef  UNICODE
#define __T(x)      L ## x
#else
#define __T(x)      x
#endif

#define _T(x)       __T(x)
#define _TEXT(x)    __T(x)

#ifndef SAFELY_DELETE
#define SAFELY_DELETE(x)   if(x != NULL){delete [] x; x = NULL;}
#endif

#ifndef SAFELY_DELETENOTARRY
#define SAFELY_DELETENOTARRY(x)   if(x != NULL){delete x; x = NULL;}
#endif

#ifndef IF_ERROR_THEN_RETURN
#define IF_ERROR_THEN_RETURN(enumError) {if(_ERROR_SUCCESS != enumError) return enumError;}
#endif

#endif //#define _RSDATATYPE_H_
