/********************************************************************************/
/*   The  Software  is  proprietary,  confidential,  and  valuable to Realsil   */
/*   Semiconductor  Corporation  ("Realsil").  All  rights, including but not   */
/*   limited  to  copyrights,  patents,  trademarks, trade secrets, mask work   */
/*   rights, and other similar rights and interests, are reserved to Realsil.   */
/*   Without  prior  written  consent  from  Realsil,  copying, reproduction,   */
/*   modification,  distribution,  or  otherwise  is strictly prohibited. The   */
/*   Software  shall  be  kept  strictly  in  confidence,  and  shall  not be   */
/*   disclosed to or otherwise accessed by any third party.                     */
/*   c<2003> - <2014>                                                           */
/*   The Software is provided "AS IS" without any warranty of any kind,         */
/*   express, implied, statutory or otherwise.                                  */
/********************************************************************************/

#ifndef _COMMONDEFINE_H_
#define _COMMONDEFINE_H_

#define SAFELY_DELETE(x)   if(x != NULL){delete [] x; x = NULL;}
#define SAFELY_DELETENOTARRY(x)   if(x != NULL){delete x; x = NULL;}

typedef enum
{
    _SCALER_START = 0,
    _SCALER_UNKNOWN = _SCALER_START,
    _SCALER_RL6156,
    _SCALER_RL6246,
    _SCALER_RL6342,
    _SCALER_RL6420,
    _SCALER_RL6001 = 0x20, // (32)
    _SCALER_RL6096,
    _SCALER_RL6192,
    _SCALER_RL6213,
    _SCALER_RL6229,
    _SCALER_RL6230, // 0x25(37)
    _SCALER_RL6269,
    _SCALER_RL6297,
    _SCALER_RL6316,
    _SCALER_RL6336,
    _SCALER_RL6193, // 0x2A(42)
    _SCALER_RLE0638,
    _SCALER_RL6369,
    _SCALER_RL6410,
    _SCALER_RLE0740,
    _SCALER_RL6432,
    _SCALER_RLE0779, // 0x30(48)
    _SCALER_RL6449,
    _SCALER_RL6463,
    _SCALER_RL6492,
    _SCALER_RL6477,//0x34 (52)
    _SCALER_RL6428,//53
    _SCALER_RL6478,//54
    _SCALER_RL6493, //55 
    _SCALER_RL6520,// 56
    _SCALER_RLE0848,// 57
    _SCALER_RL6561,//58
    _SCALER_RL6573,//59
    _SCALER_END,
    _SCALER_CUMSTOM = 0xF000,
}STRUCT_ENUM_SCALER_TYPE;

typedef enum
{
    _IC_VER_START = 0,
    _IC_VER_A = _IC_VER_START,
    _IC_VER_B,
    _IC_VER_C,
    _IC_VER_D,
    _IC_VER_E,
    _IC_VER_F,//5
    _IC_VER_G,
    _IC_VER_H,
    _IC_VER_I,
    _IC_VER_J,
    _IC_VER_K,//10
    _IC_VER_L,
    _IC_VER_M,
    _IC_VER_N,
    _IC_VER_O,
    _IC_VER_P,
    _IC_VER_END = _IC_VER_P,
}STRUCT_ENUM_IC_VERSION;

#endif // End of #ifndef _COMMONDEFINE_H_

