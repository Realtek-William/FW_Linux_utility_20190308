#include "stdafx.h"
#include "CpParseArgsBase.h"

using namespace std;

CCpParseArgsBase::CCpParseArgsBase()
{
    m_mapCmdFw.clear();
}

CCpParseArgsBase::~CCpParseArgsBase()
{

}

BOOL CCpParseArgsBase::JudgeFunctionType(INT nFuncType)
{
    INT nCount = 0;

    while(nFuncType)
    {
        nCount++;
        nFuncType = nFuncType & (nFuncType - 1);
    }

    if(nCount == 1)
    {
        return TRUE;
    }

    return FALSE;
}

BOOL CCpParseArgsBase::InsertCommandFwFile(DWORD ulIndex, string strFile)
{
    std::map<DWORD, STRUCT_COMMAND_FW_BANK>::iterator it;
    STRUCT_COMMAND_FW_BANK stCmdFw;
    string strFwPath;

    it = m_mapCmdFw.find(ulIndex);
    if(it == m_mapCmdFw.end())
    {
        stCmdFw.strFwPath = strFile;
        stCmdFw.nFwBank = 0;
        m_mapCmdFw.insert(make_pair(ulIndex, stCmdFw));
    }
    else
    {
        strFwPath = it->second.strFwPath;
        if(strFwPath.length() == 0)
        {
            it->second.strFwPath = strFile;
        }
        else
        {
            return FALSE;
        }
    }

    return TRUE;
}

BOOL CCpParseArgsBase::InsertCommandStartBank(DWORD ulIndex, string strStBank)
{
    std::map<DWORD, STRUCT_COMMAND_FW_BANK>::iterator it, itTemp;
    STRUCT_COMMAND_FW_BANK stCmdFw;
    char *pEnd;
    int nStBank;
    string strTemp;

    // get start bank
    nStBank = strtol(strStBank.c_str(), &pEnd, 0);
    strTemp = string(pEnd);
    if(!((strTemp.length() == 0) && ((nStBank >= 0) && (nStBank <= 255))))
    {
        printf("key pair should be range of 0~255!\n");
        return FALSE;
    }

    // insert map
    it = m_mapCmdFw.find(ulIndex);
    if(it == m_mapCmdFw.end())
    {
        stCmdFw.strFwPath = "";
        stCmdFw.nFwBank = nStBank;
        m_mapCmdFw.insert(make_pair(ulIndex, stCmdFw));
    }
    else
    {
/*
        for(itTemp = m_mapCmdFw.begin(); itTemp != m_mapCmdFw.end(); ++itTemp)
        {
            if(itTemp != it)
            {
                if(itTemp->second.nFwBank == nStBank)
                {
                    return FALSE;
                }
            }
        }
*/
        it->second.nFwBank = nStBank;
    }

    return TRUE;
}

string CCpParseArgsBase::GetFileFullPath(string strArg)
{
    return GetAbsolutePath(m_strCurDir + strArg);
}

BOOL CCpParseArgsBase::GetFwBankCount(string &strFile, DWORD &ulBankCnt)
{
    DWORD ulFileLength = 0;
    strFile = GetFileFullPath(strFile);

    ifstream file(strFile.c_str());
    if(!file.is_open())
    {
        return FALSE;
    }
    // Read file length
    file.seekg(0, ios::end);
    ulFileLength = (DWORD)file.tellg();
    file.seekg(0, ios::beg);
    file.close();
    ulBankCnt = (ulFileLength / 65536) + (ulFileLength % 65536 ? 1 : 0);

    return TRUE;
}

BOOL CCpParseArgsBase::JudgeFwMap(std::map<DWORD, STRUCT_FW_BANK_SETTING, sortAscending<DWORD> > &mapFw)
{
    std::map<DWORD, STRUCT_COMMAND_FW_BANK>::const_iterator it;
    int nFwCount = m_mapCmdFw.size();

    if(nFwCount == 0)
    {
        return TRUE;
    }

//     it = m_mapCmdFw.find(0);
//     if(it == m_mapCmdFw.end())
//     {
//         return false;
//     }
// 
//     for(it = m_mapCmdFw.begin(); it != m_mapCmdFw.end(); ++it)
//     {
//         if(it->first >= (DWORD)nFwCount)
//         {
//             return false;
//         }
//         if((it->second.strFwPath.length() == 0) || (it->second.nFwBank == -1))
//         {
//             return false;
//         }
//     }

    std::map<DWORD, STRUCT_FW_BANK_SETTING>::iterator itFwProg;
    STRUCT_FW_BANK_SETTING stFwProg;
    string strFile;
    DWORD ulStartBank = 0, ulBankCnt = 0, ulIndex = 0;
    for(it = m_mapCmdFw.begin(); it != m_mapCmdFw.end(); ++it)
    {
        ulStartBank = it->second.nFwBank;
        strFile = it->second.strFwPath;
        if(!GetFwBankCount(strFile, ulBankCnt))
        {
            return FALSE;
        }

        for(ulIndex = 0; ulIndex < ulBankCnt; ++ulIndex)
        {
            itFwProg = mapFw.find(ulStartBank + ulIndex);
            if(itFwProg != mapFw.end())
            {
                return FALSE;
            }
        }
        for(ulIndex = 0; ulIndex < ulBankCnt; ++ulIndex)
        {
            stFwProg.ulFwBank = ulIndex;
            stFwProg.strFwPath = strFile;
            mapFw.insert(make_pair(ulStartBank + ulIndex, stFwProg));
        }
    }

    return TRUE;
}

BOOL CCpParseArgsBase::GetSlaveAddress(string strArg, INT &nAutoSlave, BYTE &ucSlaveAddr)
{
    char *pEnd;
    int nTemp;
    string strTemp;

    if(strArg.length() == 0)
    {
        nAutoSlave = -1;
        return TRUE;
    }

    nTemp = strtol(strArg.c_str(), &pEnd, 0);
    strTemp = string(pEnd);
    if(strTemp.length() == 0)
    {
        if(nTemp == 0)
        {
            nAutoSlave = 1;
        }
        else
        {
            nAutoSlave = 0;
            ucSlaveAddr = (BYTE)nTemp;
        }
    }
    else
    {
        nAutoSlave = -1;
        return FALSE;
    }

    return TRUE;
}

BOOL CCpParseArgsBase::GetCommID(string strArg, STRUCT_ENUM_COMM_ID &enumCommID)
{
    char *pEnd;
    int nTemp;
    string strTemp;

    enumCommID = _ENUM_COMM_UNKNOWN;
	if(strArg.length() == 0)
    {
        return TRUE;
    }

    nTemp = strtol(strArg.c_str(), &pEnd, 0);
    strTemp = string(pEnd);
    if(strTemp.length() == 0)
    {
        if(((STRUCT_ENUM_COMM_ID)nTemp > _ENUM_COMM_START) && ((STRUCT_ENUM_COMM_ID)nTemp < _ENUM_COMM_END))
        {
            enumCommID = (STRUCT_ENUM_COMM_ID)nTemp;
            return TRUE;
        }
        else
        {
            return FALSE;
        }
    }
    else
    {
        return FALSE;
    }

    return TRUE;
}

void CCpParseArgsBase::GetFunctionType(int nFuncType, ENUM_ISP_FUNCTION_TYPE &enumFuncType)
{
    switch(nFuncType)
    {
    case CP_ISPTOOL_FUNC_ERASE:
        enumFuncType = _ENUM_FUNC_ERASE;
        break;
    case CP_ISPTOOL_FUNC_ISP_NORMAL:
        enumFuncType = _ENUM_FUNC_ISP_NORMAL;
        break;
    case CP_ISPTOOL_FUNC_ISP_NORMAL_HW_SIGN:
        enumFuncType = _ENUM_FUNC_ISP_NORMAL_HW_SIGN;
        break;
    case CP_ISPTOOL_FUNC_ISP_NORMAL_SW_SIGN:
        enumFuncType = _ENUM_FUNC_ISP_NORMAL_SW_SIGN;
        break;
    case CP_ISPTOOL_FUNC_ISP_FW_PARTITION:
        enumFuncType = _ENUM_FUNC_ISP_FW_PARTITION;
        break;
    case CP_ISPTOOL_FUNC_ISP_FW_PARTITION_HW_SIGN:
        enumFuncType = _ENUM_FUNC_ISP_FW_PARTITION_HW_SIGN;
        break;
    case CP_ISPTOOL_FUNC_ISP_FW_PARTITION_SW_SIGN:
        enumFuncType = _ENUM_FUNC_ISP_FW_PARTITION_SW_SIGN;
        break;
    case CP_ISPTOOL_FUNC_ISP_DIFFER_BANK:
        enumFuncType = _ENUM_FUNC_ISP_DIFFER_BANK;
        break;
    case CP_ISPTOOL_FUNC_ISP_DIFFER_BANK_HW_SIGN:
        enumFuncType = _ENUM_FUNC_ISP_DIFFER_BANK_HW_SIGN;
        break;
    case CP_ISPTOOL_FUNC_ISP_DIFFER_BANK_SW_SIGN:
        enumFuncType = _ENUM_FUNC_ISP_DIFFER_BANK_SW_SIGN;
        break;
    case CP_ISPTOOL_FUNC_ISP_COPY_BANK:
        enumFuncType = _ENUM_FUNC_ISP_COPY_BANK;
        break;
    case CP_ISPTOOL_FUNC_ISP_COPY_BANK_HW_SIGN:
        enumFuncType = _ENUM_FUNC_ISP_COPY_BANK_HW_SIGN;
        break;
    case CP_ISPTOOL_FUNC_ISP_COPY_BANK_SW_SIGN:
        enumFuncType = _ENUM_FUNC_ISP_COPY_BANK_SW_SIGN;
        break;
    default:
        enumFuncType = _ENUM_FUNC_UNKNOWN;
        break;
    }
}

void CCpParseArgsBase::GetReadVerType(int nType, ENUM_READ_VER_TYPE &enumType)
{
    switch(nType)
    {
    case CP_ISPTOOL_VER_FROM_REG:
        enumType = _ENUM_VER_FROM_REG;
        break;
    case CP_ISPTOOL_VER_FROM_DDCCI:
        enumType = _ENUM_VER_FROM_DDCCI;
        break;
    case CP_ISPTOOL_VER_FROM_FLASH:
        enumType = _ENUM_VER_FROM_FLASH;
        break;
    default:
        enumType = _ENUM_VER_FROM_REG;
        break;
    }
}

BOOL CCpParseArgsBase::GetArgsIntValue(string strArg, INT &nValue)
{
    char *pEnd;
    int nTemp;
    string strTemp;

    if(strArg.length() == 0)
    {
        nValue = -1;
        return TRUE;
    }

    nTemp = strtol(strArg.c_str(), &pEnd, 0);
    strTemp = string(pEnd);
    if(strTemp.length() == 0)
    {
        nValue = nTemp;
    }
    else
    {
        nValue = -1;
        return FALSE;
    }

    return TRUE;
}

BOOL CCpParseArgsBase::JudgeArgument(STRUCT_COMMAND_ARGS_SETTING stArgSetting)
{
    INT nValue = 0;

    // function type
    if(!JudgeFunctionType(stArgSetting.nFunc) && !JudgeFunctionType(stArgSetting.nVerType))
    {
        return FALSE;
    }

    // comm id
    if(!GetCommID(stArgSetting.strCommID, m_stCmd.stIspSetting.enumCommID))
    {
        return FALSE;
    }

    // slave address
    if(!GetSlaveAddress(stArgSetting.strSlave, m_stCmd.stIspSetting.nAutoSlave, m_stCmd.stIspSetting.ucSlaveAddr))
    {
        printf("salve address illegal!\n");
        return FALSE;
    }

    if(!JudgeFwMap(m_stCmd.stIspSetting.mapFw))
    {
        return FALSE;
    }

    GetFunctionType(stArgSetting.nFunc, m_stCmd.stIspSetting.enumFuncType);

    // read version
    if(stArgSetting.bReadVer)
    {
        if(!JudgeFunctionType(stArgSetting.nVerType))
        {
            printf("read version type illegal!");
            return FALSE;
        }

        m_stCmd.stIspSetting.stReadVer.bNeedRead = true;
        GetReadVerType(stArgSetting.nVerType, m_stCmd.stIspSetting.stReadVer.enumType);
    }
    else
    {
        m_stCmd.stIspSetting.stReadVer.bNeedRead = false;
    }

    // flash partition setting
    if((m_stCmd.stIspSetting.enumFuncType == _ENUM_FUNC_ISP_FW_PARTITION)
        || (m_stCmd.stIspSetting.enumFuncType == _ENUM_FUNC_ISP_FW_PARTITION_HW_SIGN)
        || (m_stCmd.stIspSetting.enumFuncType == _ENUM_FUNC_ISP_FW_PARTITION_SW_SIGN))
    {
        if(!GetArgsIntValue(stArgSetting.strUserFlagAddr, nValue))
        {
            printf("user flag address illegal!");
            return FALSE;
        }
        m_stCmd.stIspSetting.stFlag.ulAddr = (DWORD)nValue;
    }
	
    return TRUE;
}

