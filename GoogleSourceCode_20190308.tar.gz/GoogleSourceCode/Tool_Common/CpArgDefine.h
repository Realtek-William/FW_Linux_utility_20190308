#pragma once
#ifndef _CP_ARGS_DEFINE_H
#define  _CP_ARGS_DEFINE_H

#include "RsDataType.h"
#include <string>
#include <map>
#include "../CpComm/Comm_Export/CpCommInclude.h"

#define UL_BOOT_FLAG_COUNT 8

typedef enum
{
    _ENUM_FUNC_ERASE = 0,
    _ENUM_FUNC_ISP_NORMAL,
    _ENUM_FUNC_ISP_NORMAL_HW_SIGN,
    _ENUM_FUNC_ISP_NORMAL_SW_SIGN,
    _ENUM_FUNC_ISP_FW_PARTITION,
    _ENUM_FUNC_ISP_FW_PARTITION_HW_SIGN,
    _ENUM_FUNC_ISP_FW_PARTITION_SW_SIGN,
    _ENUM_FUNC_ISP_DIFFER_BANK,
    _ENUM_FUNC_ISP_DIFFER_BANK_HW_SIGN,
    _ENUM_FUNC_ISP_DIFFER_BANK_SW_SIGN,
    _ENUM_FUNC_ISP_COPY_BANK,
    _ENUM_FUNC_ISP_COPY_BANK_HW_SIGN,
    _ENUM_FUNC_ISP_COPY_BANK_SW_SIGN,
    _ENUM_FUNC_SET_SR_STATUS,
    _ENUM_FUNC_READ_FLASH_TYPE,
    _ENUM_FUNC_READ_SR,
    _ENUM_FUNC_WRITE_SR,
    _ENUM_FUNC_READ_SAFEGUARD_REG,
    _ENUM_FUNC_WRITE_SAFEGUARD_REG,
    _ENUM_FUNC_RESET_MCU,
    _ENUM_FUNC_DUMP_FLASH,

    _ENUM_FUNC_UNKNOWN = 0xFF
}ENUM_ISP_FUNCTION_TYPE;

typedef struct STRUCT_FW_BANK_SETTING
{
    DWORD ulFwBank;
    string strFwPath;
}STRUCT_FW_BANK_SETTING;

template <class T> struct sortAscending : binary_function <T, T, bool>
{
    bool operator() (const T& x, const T& y) const
    {
        return x < y;
    }
};

typedef enum
{
    _ENUM_VER_FROM_REG = 0,
    _ENUM_VER_FROM_DDCCI,
    _ENUM_VER_FROM_FLASH,
    _ENUM_VER_UNKNOWN
}ENUM_READ_VER_TYPE;

struct STRUCT_READ_VER_SETTING
{
    bool bNeedRead;
    ENUM_READ_VER_TYPE enumType;
};

typedef struct STRUCT_BOOT_FLAG_SETTING
{
    // Address and flag data
    DWORD ulAddr;
    /*---The actual len---*/
    /*---find the first no 0xFF flag from ---*/
    /*---the ucszFlag[UL_BOOT_FLAG_COUNT - 1] to ucszFlag[0]---*/
    BYTE ucszFlag[UL_BOOT_FLAG_COUNT];

    STRUCT_BOOT_FLAG_SETTING():ulAddr(0)
    {
        memset(ucszFlag, 0xFF, sizeof(ucszFlag));
        ucszFlag[0] = 0xAA;
        ucszFlag[1] = 0x55;
    }
}STRUCT_BOOT_FLAG_SETTING;

struct STRUCT_CP_ISP_COMMAND_SETTING
{
    STRUCT_ENUM_COMM_ID enumCommID;
    ENUM_ISP_FUNCTION_TYPE enumFuncType;
    STRUCT_READ_VER_SETTING stReadVer;
    std::map<DWORD, STRUCT_FW_BANK_SETTING, sortAscending<DWORD> > mapFw;
    INT nAutoSlave;
    BYTE ucSlaveAddr;
    STRUCT_BOOT_FLAG_SETTING stFlag;

    STRUCT_CP_ISP_COMMAND_SETTING() :enumFuncType(_ENUM_FUNC_UNKNOWN), 
        nAutoSlave(-1), ucSlaveAddr(0x94)
    {}
};

struct STRUCT_CP_ISP_TOOL_COMMAND
{
    STRUCT_CP_ISP_COMMAND_SETTING stIspSetting;
    std::string strSig;
    std::string strKeyPair;
    std::string strPublic;
    std::string strSubCert;

    STRUCT_CP_ISP_TOOL_COMMAND() : strSig(""), strKeyPair(""), strPublic(""), strSubCert("")
    {}
};

#define IS_Digital_SW_Verify(FuncType)      ((FuncType == _ENUM_FUNC_ISP_NORMAL_SW_SIGN) \
                                            || (FuncType == _ENUM_FUNC_ISP_COPY_BANK_SW_SIGN) \
                                            || (FuncType == _ENUM_FUNC_ISP_DIFFER_BANK_SW_SIGN))

#endif