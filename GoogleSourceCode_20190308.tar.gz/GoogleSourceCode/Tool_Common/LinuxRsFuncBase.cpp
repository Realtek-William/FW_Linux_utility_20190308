#include "stdafx.h"
#include "CpRsFuncBase.h"

CCpRsString GetCurrentProcessDir(VOID* hModule)
{
    static TCHAR buf[_MAX_PATH];  
    int i;  
    CHAR *pDest;

    // get exe 
    if(hModule == NULL)
    {
        int len = readlink("/proc/self/exe", buf, _MAX_PATH);  
        if (len < 0 || len >= _MAX_PATH)  
        {  
            return NULL;  
        }  
          
        buf[len] = '\0';  
        for(i = len; i >= 0; i--)  
        {  
            if(buf[i] == '/')  
            {  
                buf[i + 1] = '\0';  
                break;  
            }  
        }  
    }
    else // .so path
    {
        Dl_info dlinfo;
        int ret=0;ret = dladdr(hModule,&dlinfo);
        if(!ret)
        {
            buf[0]='\0' ;
        }
        else
        {
            strncpy(buf, dlinfo.dli_fname,_MAX_PATH);
            pDest = strrchr(buf, '/');
            if(pDest != NULL)
            {
                pDest[1] = '\0';
            }
            else
            {
                pDest = strrchr(buf, '\\');
                if(pDest != NULL)
                {
                    pDest[1] = '\0';
                }
                else
                {
                    memcpy(buf,"./",sizeof("./"));
                }
            }
        }
        
    }
    return buf;  
}


#define MAX_ABSOLUTE_PATH_LENGTH 40960

string GetAbsolutePath(string path)
{
    char resolved_path[MAX_ABSOLUTE_PATH_LENGTH] = {0};

    realpath(path.c_str(), resolved_path);

    return string(resolved_path);
}
