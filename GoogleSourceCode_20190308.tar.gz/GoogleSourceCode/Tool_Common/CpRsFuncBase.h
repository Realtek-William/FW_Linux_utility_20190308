#pragma once
#ifndef _RSFUNCBASE_H_
#define _RSFUNCBASE_H_
#include "RsDataType.h"
#include "CpRsString.h"

#ifdef UNICODE
#ifndef GetPrivateProfileString
#define GetPrivateProfileString  GetPrivateProfileStringW
#endif // !GetPrivateProfileString
#ifndef GetPrivateProfileInt
#define GetPrivateProfileInt  GetPrivateProfileIntW
#endif // !GetPrivateProfileInt
#ifndef WritePrivateProfileString
#define WritePrivateProfileString  WritePrivateProfileStringW
#endif // !GetPrivateProfileInt
#else
#ifndef GetPrivateProfileString
#define GetPrivateProfileString  CpRsGetPrivateProfileString
#endif // !GetPrivateProfileString
#ifndef GetPrivateProfileInt
#define GetPrivateProfileInt  CpRsGetPrivateProfileInt
#endif // !GetPrivateProfileInt
#ifndef WritePrivateProfileString
#define WritePrivateProfileString  CpRsWritePrivateProfileString
#endif // !GetPrivateProfileInt

#endif // !UNICODE
UINT CpRsGetPrivateProfileInt(CHAR *pAppName, CHAR *pkeyName, INT nDefault, CHAR *pFileName);
INT CpRsGetPrivateProfileString(CHAR *pAppName, CHAR *pkeyName, CHAR *pDefault, CHAR * pcszBuff, DWORD nSize, CHAR *pFileName);
BOOL CpRsWritePrivateProfileString(CHAR *lpAppName, CHAR * lpKeyName, CHAR * lpString, CHAR * lpFileName);
BOOL CpRsSaveAnsiFile(CCpRsString strFile, CCpRsString strBuffer, DWORD ulLength);
CCpRsString GetCurrentProcessDir(VOID* hModule = NULL);
string GetAbsolutePath(string path);

#endif // End of #ifndef _RSFUNCBASE_H_
