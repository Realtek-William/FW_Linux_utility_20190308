#pragma once
#include <iostream>
#include <stdio.h>
#include <stdarg.h>
#include "RsDataType.h"
using namespace std;
#ifdef  UNICODE
#ifndef CpRsStringBase
typedef std::wstring CpRsStringBase;
#define CpRsnprintf vswprintf
#endif
#else 
#ifndef CpRsStringBase
typedef std::string CpRsStringBase;
#define CpRsnprintf vsnprintf
#endif
#endif

class CCpRsString: public CpRsStringBase
{
public:
    CCpRsString();
    CCpRsString(const CCpRsString& str);
    CCpRsString(const CCpRsString& str, size_t pos, size_t len = npos);
    CCpRsString(const TCHAR* s);
    CCpRsString(const TCHAR* s, size_t n);
    CCpRsString(size_t n, TCHAR c);
    virtual ~CCpRsString();

    CCpRsString& operator= (const CpRsStringBase& str);
    CCpRsString& operator= (const CCpRsString& str);
    CCpRsString& operator= (const TCHAR* s);
    CCpRsString& operator= (TCHAR c);
    friend CCpRsString operator+ (const CCpRsString& lhs, const CCpRsString& rhs);
    friend CCpRsString operator+ (const CCpRsString& lhs, const TCHAR*   rhs);
    friend CCpRsString operator+ (const TCHAR*   lhs, const CCpRsString& rhs);
    friend CCpRsString operator+ (const CCpRsString& lhs, TCHAR          rhs);
    friend CCpRsString operator+ (TCHAR          lhs, const CCpRsString& rhs);
 
    friend bool operator== (const CCpRsString& lhs, const CCpRsString& rhs);
    friend bool operator== (const TCHAR*   lhs, const CCpRsString& rhs);
    friend bool operator== (const CCpRsString& lhs, const TCHAR*   rhs);
    friend bool operator!= (const CCpRsString& lhs, const CCpRsString& rhs);
    friend bool operator!= (const TCHAR*   lhs, const CCpRsString& rhs);
    friend bool operator!= (const CCpRsString& lhs, const TCHAR*   rhs);
    friend bool operator<  (const CCpRsString& lhs, const CCpRsString& rhs);
    friend bool operator<  (const TCHAR*   lhs, const CCpRsString& rhs);
    friend bool operator<  (const CCpRsString& lhs, const TCHAR*   rhs);
    friend bool operator<= (const CCpRsString& lhs, const CCpRsString& rhs);
    friend bool operator<= (const TCHAR*   lhs, const CCpRsString& rhs);
    friend bool operator<= (const CCpRsString& lhs, const TCHAR*   rhs);
    friend bool operator>  (const CCpRsString& lhs, const CCpRsString& rhs);
    friend bool operator>  (const TCHAR*   lhs, const CCpRsString& rhs);
    friend bool operator>  (const CCpRsString& lhs, const TCHAR*   rhs);
    friend bool operator>= (const CCpRsString& lhs, const CCpRsString& rhs);
    friend bool operator>= (const TCHAR*   lhs, const CCpRsString& rhs);
    friend bool operator>= (const CCpRsString& lhs, const TCHAR*   rhs);
    friend istream& operator >> (istream& is, CCpRsString& str);
    friend ostream& operator<< (ostream& os, const CCpRsString& str);
//     friend istream& getline(istream&  is, CCpRsString& str, TCHAR delim);
//     friend istream& getline(istream&& is, CCpRsString& str, TCHAR delim);
//     friend istream& getline(istream&  is, CCpRsString& str);
//     friend istream& getline(istream&& is, CCpRsString& str);
    void Format(const TCHAR *pszFmt, ...);
    CCpRsString Left(INT nCount) const;
private:
    CpRsStringBase m_string;
};

