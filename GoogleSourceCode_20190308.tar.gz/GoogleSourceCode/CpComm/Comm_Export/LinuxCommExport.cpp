/********************************************************************************/
/*   The  Software  is  proprietary,  confidential,  and  valuable to Realsil   */
/*   Semiconductor  Corporation  ("Realsil").  All  rights, including but not   */
/*   limited  to  copyrights,  patents,  trademarks, trade secrets, mask work   */
/*   rights, and other similar rights and interests, are reserved to Realsil.   */
/*   Without  prior  written  consent  from  Realsil,  copying, reproduction,   */
/*   modification,  distribution,  or  otherwise  is strictly prohibited. The   */
/*   Software  shall  be  kept  strictly  in  confidence,  and  shall  not be   */
/*   disclosed to or otherwise accessed by any third party.                     */
/*   c<2003> - <2014>                                                           */
/*   The Software is provided "AS IS" without any warranty of any kind,         */
/*   express, implied, statutory or otherwise.                                  */
/********************************************************************************/
#include "CpCommExport.h"
#include <iostream>
#include <stdio.h>
#include <dlfcn.h>
using namespace std;
#include "../../Tool_Common/CpRsString.h"
#include "../../Tool_Common/CpRsFuncBase.h"

//////////////////////////////////////////////////////////////////////////
// CCpRsComm
//////////////////////////////////////////////////////////////////////////
BOOL CCpRsComm::LoadCommDllFile(TCHAR* pcFile)
{
    FreeCommDllFile();

    m_hCommDll = dlopen(pcFile, RTLD_NOW);
    if(m_hCommDll == NULL)
    {
        return FALSE;
    }

    m_rsGetI2CPageLength = (func_rsGetI2CPageLength)dlsym(m_hCommDll, "GetI2CPageLength");
    if(m_rsGetI2CPageLength == NULL)
    {
        FreeCommDllFile();
        return FALSE;
    }

    m_rsGetNativePageLength = (func_rsGetNativePageLength)dlsym(m_hCommDll, "GetNativePageLength");
    if(m_rsGetNativePageLength == NULL)
    {
        FreeCommDllFile();
        return FALSE;
    }

    m_rsI2CWrite = (func_rsI2CWrite)dlsym(m_hCommDll, "I2CWrite");
    if(m_rsI2CWrite == NULL)
    {
        FreeCommDllFile();
        return FALSE;
    }

    m_rsI2CRead = (func_rsI2CRead)dlsym(m_hCommDll, "I2CRead");
    if(m_rsI2CRead == NULL)
    {
        FreeCommDllFile();
        return FALSE;
    }

    m_rsI2CWriteByte = (func_rsI2CWriteByte)dlsym(m_hCommDll, "I2CWriteByte");
    if(m_rsI2CWriteByte == NULL)
    {
        FreeCommDllFile();
        return FALSE;
    }

    m_rsI2CCurrentRead = (func_rsI2CCurrentRead)dlsym(m_hCommDll, "I2CCurrentRead");
    if(m_rsI2CCurrentRead == NULL)
    {
        FreeCommDllFile();
        return FALSE;
    }

    m_rsI2CWordWrite = (func_rsI2CWordWrite)dlsym(m_hCommDll, "I2CWordWrite");
    if(m_rsI2CWordWrite == NULL)
    {
        FreeCommDllFile();
        return FALSE;
    }


    m_rsI2CWordRead = (func_rsI2CWordRead)dlsym(m_hCommDll, "I2CWordRead");
    if(m_rsI2CWordRead == NULL)
    {
        FreeCommDllFile();
        return FALSE;
    }

    m_rsI2CWriteEx = (func_rsI2CWriteEx)dlsym(m_hCommDll, "I2CWriteEx");
    if(m_rsI2CWriteEx == NULL)
    {
        FreeCommDllFile();
        return FALSE;
    }

    m_rsI2CReadEx = (func_rsI2CReadEx)dlsym(m_hCommDll, "I2CReadEx");
    if(m_rsI2CReadEx == NULL)
    {
        FreeCommDllFile();
        return FALSE;
    }

    m_rsI2CCurrentReadEx = (func_rsI2CCurrentReadEx)dlsym(m_hCommDll, "I2CCurrentReadEx");
    if(m_rsI2CCurrentReadEx == NULL)
    {
        FreeCommDllFile();
        return FALSE;
    }

    m_rsI2CWordWriteEx = (func_rsI2CWordWriteEx)dlsym(m_hCommDll, "I2CWordWriteEx");
    if(m_rsI2CWordWriteEx == NULL)
    {
        FreeCommDllFile();
        return FALSE;
    }

    m_rsI2CWordReadEx = (func_rsI2CWordReadEx)dlsym(m_hCommDll, "I2CWordReadEx");
    if(m_rsI2CWordReadEx == NULL)
    {
        FreeCommDllFile();
        return FALSE;
    }

    m_rsAdjustOption = (func_rsAdjustOption)dlsym(m_hCommDll, "AdjustOption");
    if(m_rsAdjustOption == NULL)
    {
        FreeCommDllFile();
        return FALSE;
    }

    m_rsSetI2CSpeed = (func_rsSetI2CSpeed)dlsym(m_hCommDll, "SetI2CSpeed");
    if(m_rsSetI2CSpeed == NULL)
    {
        FreeCommDllFile();
        return FALSE;
    }

    m_rsGetI2CSpeed = (func_rsGetI2CSpeed)dlsym(m_hCommDll, "GetI2CSpeed");
    if(m_rsGetI2CSpeed == NULL)
    {
        FreeCommDllFile();
        return FALSE;
    }

    m_rsSetAuxMode = (func_rsSetAuxMode)dlsym(m_hCommDll, "SetAuxMode");
    if(m_rsSetAuxMode == NULL)
    {
        FreeCommDllFile();
        return FALSE;
    }

    m_rsSetWaitingMode = (func_rsSetWaitingMode)dlsym(m_hCommDll, "SetWaitingMode");
    if(m_rsSetWaitingMode == NULL)
    {
        FreeCommDllFile();
        return FALSE;
    }

    m_rsGetWaitingMode = (func_rsGetWaitingMode)dlsym(m_hCommDll, "GetWaitingMode");
    if(m_rsGetWaitingMode == NULL)
    {
        FreeCommDllFile();
        return FALSE;
    }

    m_rsInitiallize = (func_rsInitiallize)dlsym(m_hCommDll, "Initiallize");
    if(m_rsInitiallize == NULL)
    {
        FreeCommDllFile();
        return FALSE;
    }
    m_rsGetCommCount = (func_rsGetCommCount)dlsym(m_hCommDll, "GetCommCount");
    if(m_rsGetCommCount == NULL)
    {
        FreeCommDllFile();
        return FALSE;
    }
    m_rsInitiallize();

    m_rsGetCommID = (func_rsGetCommID)dlsym(m_hCommDll, "GetCommID");
    if(m_rsGetCommID == NULL)
    {
        FreeCommDllFile();
        return FALSE;
    }

    m_rsGetCommName = (func_rsGetCommName)dlsym(m_hCommDll, "GetCommName");
    if(m_rsGetCommName == NULL)
    {
        FreeCommDllFile();
        return FALSE;
    }



    m_rsSetCommByIndex = (func_rsSetCommByIndex)dlsym(m_hCommDll, "SetCommByIndex");
    if(m_rsSetCommByIndex == NULL)
    {
        FreeCommDllFile();
        return FALSE;
    }

    m_rsSetCommByID = (func_rsSetCommByID)dlsym(m_hCommDll, "SetCommByID");
    if(m_rsSetCommByID == NULL)
    {
        FreeCommDllFile();
        return FALSE;
    }

    m_rsGetCommFile = (func_rsGetCommFile)dlsym(m_hCommDll, "GetCommFile");
    if (m_rsGetCommFile == NULL)
    {
        FreeCommDllFile();
        return FALSE;
    }
       m_rsSetDebugSlave = (func_rsSetDebugSlave)dlsym(m_hCommDll, "SetDebugSlave");
       if(m_rsSetDebugSlave == NULL)
       {
           FreeCommDllFile();
           return FALSE;
       }

       m_rsSetIspSlave = (func_rsSetIspSlave)dlsym(m_hCommDll, "SetIspSlave");
       if(m_rsSetIspSlave == NULL)
       {
           FreeCommDllFile();
           return FALSE;
       }

       m_rsSetIspContinuousSlave = (func_rsSetIspContinuousSlave)dlsym(m_hCommDll, "SetIspContinuousSlave");
       if(m_rsSetIspContinuousSlave == NULL)
       {
           FreeCommDllFile();
           return FALSE;
       }

       m_rsGetDebugSlave = (func_rsGetDebugSlave)dlsym(m_hCommDll, "GetDebugSlave");
       if(m_rsGetDebugSlave == NULL)
       {
           FreeCommDllFile();
           return FALSE;
       }

       m_rsGetIspSlave = (func_rsGetIspSlave)dlsym(m_hCommDll, "GetIspSlave");
       if(m_rsGetIspSlave == NULL)
       {
           FreeCommDllFile();
           return FALSE;
       }

       m_rsGetIspContinuousSlave = (func_rsGetIspContinuousSlave)dlsym(m_hCommDll, "GetIspContinuousSlave");
       if(m_rsGetIspContinuousSlave == NULL)
       {
           FreeCommDllFile();
           return FALSE;
       }

       m_rsSetDebugMode = (func_rsSetDebugMode)dlsym(m_hCommDll, "SetDebugMode");
       if(m_rsSetDebugMode == NULL)
       {
           FreeCommDllFile();
           return FALSE;
       }

       m_rsGetDebugMode = (func_rsGetDebugMode)dlsym(m_hCommDll, "GetDebugMode");
       if(m_rsGetDebugMode == NULL)
       {
           FreeCommDllFile();
           return FALSE;
       }

       m_rsReadReg = (func_rsReadReg)dlsym(m_hCommDll, "ReadReg");
       if(m_rsReadReg == NULL)
       {
           FreeCommDllFile();
           return FALSE;
       }

       m_rsWriteReg = (func_rsWriteReg)dlsym(m_hCommDll, "WriteReg");
       if(m_rsWriteReg == NULL)
       {
           FreeCommDllFile();
           return FALSE;
       }

       m_rsReadRegs = (func_rsReadRegs)dlsym(m_hCommDll, "ReadRegs");
       if (m_rsReadRegs == NULL)
       {
           FreeCommDllFile();
           return FALSE;
       }

       m_rsWriteRegs = (func_rsWriteRegs)dlsym(m_hCommDll, "WriteRegs");
       if(m_rsWriteRegs == NULL)
       {
           FreeCommDllFile();
           return FALSE;
       }

       m_rsWriteRegBit = (func_rsWriteRegBit)dlsym(m_hCommDll, "WriteRegBit");
       if (m_rsWriteRegBit == NULL)
       {
           FreeCommDllFile();
           return FALSE;
       }

       m_rsWritePortRegBit = (func_rsWritePortRegBit)dlsym(m_hCommDll, "WritePortRegBit");
       if (m_rsWritePortRegBit == NULL)
       {
           FreeCommDllFile();
           return FALSE;
       }

       m_rsReadRegEx = (func_rsReadRegEx)dlsym(m_hCommDll, "ReadRegEx");
       if(m_rsReadRegEx == NULL)
       {
           FreeCommDllFile();
           return FALSE;
       }

       m_rsWriteRegEx = (func_rsWriteRegEx)dlsym(m_hCommDll, "WriteRegEx");
       if(m_rsWriteRegEx == NULL)
       {
           FreeCommDllFile();
           return FALSE;
       }

       m_rsReadRegsEx = (func_rsReadRegsEx)dlsym(m_hCommDll, "ReadRegsEx");
       if (m_rsReadRegsEx == NULL)
       {
           FreeCommDllFile();
           return FALSE;
       }

       m_rsWriteRegsEx = (func_rsWriteRegsEx)dlsym(m_hCommDll, "WriteRegsEx");
       if(m_rsWriteRegsEx == NULL)
       {
           FreeCommDllFile();
           return FALSE;
       }

       m_rsWriteRegBitEx = (func_rsWriteRegBitEx)dlsym(m_hCommDll, "WriteRegBitEx");
       if (m_rsWriteRegBitEx == NULL)
       {
           FreeCommDllFile();
           return FALSE;
       }

       m_rsWritePortRegBitEx = (func_rsWritePortRegBitEx)dlsym(m_hCommDll, "WritePortRegBitEx");
       if (m_rsWritePortRegBitEx == NULL)
       {
           FreeCommDllFile();
           return FALSE;
       }

       m_rsReadSysDevice = (func_rsReadSysDevice)dlsym(m_hCommDll, "ReadSysDevice");
       if(m_rsReadSysDevice == NULL)
       {
           FreeCommDllFile();
           return FALSE;
       }

       m_rsWriteSysDevice = (func_rsWriteSysDevice)dlsym(m_hCommDll, "WriteSysDevice");
       if(m_rsWriteSysDevice == NULL)
       {
           FreeCommDllFile();
           return FALSE;
       }

       m_rsReadWordSysDevice = (func_rsReadWordSysDevice)dlsym(m_hCommDll, "ReadWordSysDevice");
       if(m_rsReadWordSysDevice == NULL)
       {
           FreeCommDllFile();
           return FALSE;
       }

       m_rsWriteWordSysDevice = (func_rsWriteWordSysDevice)dlsym(m_hCommDll, "WriteWordSysDevice");
       if(m_rsWriteWordSysDevice == NULL)
       {
           FreeCommDllFile();
           return FALSE;
       }

       m_rsScalerStop = (func_rsScalerStop)dlsym(m_hCommDll, "ScalerStop");
       if (m_rsScalerStop == NULL)
       {
           FreeCommDllFile();
           return FALSE;
       }

       m_rsScalerRun = (func_rsScalerRun)dlsym(m_hCommDll, "ScalerRun");
       if(m_rsScalerRun == NULL)
       {
           FreeCommDllFile();
           return FALSE;
       }

       m_rsWriteMcuReg = (func_rsWriteMcuReg)dlsym(m_hCommDll, "WriteMcuReg");
       if(m_rsWriteMcuReg == NULL)
       {
           FreeCommDllFile();
           return FALSE;
       }

       m_rsWriteMcuRegBit = (func_rsWriteMcuRegBit)dlsym(m_hCommDll, "WriteMcuRegBit");
       if(m_rsWriteMcuRegBit == NULL)
       {
           FreeCommDllFile();
           return FALSE;
       }

       m_rsReadMcuReg = (func_rsReadMcuReg)dlsym(m_hCommDll, "ReadMcuReg");
       if(m_rsReadMcuReg == NULL)
       {
           FreeCommDllFile();
           return FALSE;
       }

       m_rsWriteMcuRegs = (func_rsWriteMcuRegs)dlsym(m_hCommDll, "WriteMcuRegs");
       if(m_rsWriteMcuRegs == NULL)
       {
           FreeCommDllFile();
           return FALSE;
       }

       m_rsReadMcuRegs = (func_rsReadMcuRegs)dlsym(m_hCommDll, "ReadMcuRegs");
       if(m_rsReadMcuRegs == NULL)
       {
           FreeCommDllFile();
           return FALSE;
       }

       m_rsWriteContinuousMcuReg = (func_rsWriteContinuousMcuReg)dlsym(m_hCommDll, "WriteContinuousMcuReg");
       if(m_rsWriteContinuousMcuReg == NULL)
       {
           FreeCommDllFile();
           return FALSE;
       }

       m_rsReadContinuousMcuReg = (func_rsReadContinuousMcuReg)dlsym(m_hCommDll, "ReadContinuousMcuReg");
       if(m_rsReadContinuousMcuReg == NULL)
       {
           FreeCommDllFile();
           return FALSE;
       }

       m_rsReleaseDev = (func_rsReleaseDev)dlsym(m_hCommDll, "ReleaseDev");
       if(m_rsReleaseDev == NULL)
       {
           FreeCommDllFile();
           return FALSE;
       }
       m_rsNativeWrite = (func_rsNativeWrite)dlsym(m_hCommDll, "NativeWrite");
       if(m_rsNativeWrite == NULL)
       {
           FreeCommDllFile();
           return FALSE;
       }

       m_rsNativeRead = (func_rsNativeRead)dlsym(m_hCommDll, "NativeRead");
       if(m_rsNativeRead == NULL)
       {
           FreeCommDllFile();
           return FALSE;
       }

       m_rsSetConfigFilePath = (func_rsSetConfigFilePath)dlsym(m_hCommDll, "SetSettingFilePath");
       if(m_rsSetConfigFilePath == NULL)
       {
           FreeCommDllFile();
           return FALSE;
       }

       m_rsGetDeviceHandler = (func_rsGetDeviceHandler)dlsym(m_hCommDll, "GetDeviceHandler");
       if(m_rsGetDeviceHandler == NULL)
       {
           FreeCommDllFile();
           return FALSE;
       }

       m_rsResetFirmware = (func_rsResetFirmware)dlsym(m_hCommDll, "ResetFirmware");
       if(m_rsResetFirmware == NULL)
       {
           FreeCommDllFile();
           return FALSE;
       }

       m_rsEnterIspMode = (func_rsEnterIspMode)dlsym(m_hCommDll, "EnterIspMode");
       if(m_rsEnterIspMode == NULL)
       {
           FreeCommDllFile();
           return FALSE;
       }

       m_rsGetSMBUSDataType = (func_rsGetSMBUSDataType)dlsym(m_hCommDll, "GetSMBUSDataType");
       if(m_rsGetSMBUSDataType == NULL)
       {
           FreeCommDllFile();
           return FALSE;
       }

       m_rsSetSMBUSDataType = (func_rsSetSMBUSDataType)dlsym(m_hCommDll, "SetSMBUSDataType");
       if(m_rsSetSMBUSDataType == NULL)
       {
           FreeCommDllFile();
           return FALSE;
       }
       m_rsGetDeviceCount = (func_rsGetDeviceCount)dlsym(m_hCommDll, "GetDeviceCount");
       if(m_rsGetDeviceCount == NULL)
       {
           FreeCommDllFile();
           return FALSE;
       }
       m_rsRemoveDevice = (func_rsRemoveDevice)dlsym(m_hCommDll, "RemoveDevice");
       if(m_rsRemoveDevice == NULL)
       {
           FreeCommDllFile();
           return FALSE;
       }
       m_rsAutoDetectSlaveAddr = (func_rsAutoDetectSlaveAddr)dlsym(m_hCommDll, "AutoDetectSlaveAddr");
       if(m_rsAutoDetectSlaveAddr == NULL)
       {
           FreeCommDllFile();
           return FALSE;
       }

       m_rsDDCCIWrite = (func_rsDDCCIWrite)dlsym(m_hCommDll, "DDCCIWrite");
       if(m_rsDDCCIWrite == NULL)
       {
           FreeCommDllFile();
           return FALSE;
       }
       m_rsDDCCIRead = (func_rsDDCCIRead)dlsym(m_hCommDll, "DDCCIRead");
       if(m_rsDDCCIRead == NULL)
       {
           FreeCommDllFile();
           return FALSE;
       }
       m_rsDDCCIRead = (func_rsDDCCIRead)dlsym(m_hCommDll, "DDCCIRead");
       if(m_rsDDCCIRead == NULL)
       {
           FreeCommDllFile();
           return FALSE;
       }
       m_rsSetFTDIGetAck = (func_rsSetFTDIGetAck)dlsym(m_hCommDll, "SetFTDIGetAck");
       if(m_rsSetFTDIGetAck == NULL)
       {
           FreeCommDllFile();
           return FALSE;
       }
       m_rsGetFTDIGetAckStatus = (func_rsGetFTDIGetAckStatus)dlsym(m_hCommDll, "GetFTDIGetAckStatus");
       if(m_rsGetFTDIGetAckStatus == NULL)
       {
           FreeCommDllFile();
           return FALSE;
       }
       m_rsI2CMasterInitial = (func_rsI2CMasterInitial)dlsym(m_hCommDll, "I2CMasterInitial");
       if(m_rsI2CMasterInitial == NULL)
       {
           FreeCommDllFile();
           return FALSE;
       }
       m_rsI2CMasterCurrentRead = (func_rsI2CMasterCurrentRead)dlsym(m_hCommDll, "I2CMasterCurrentRead");
       if(m_rsI2CMasterCurrentRead == NULL)
       {
           FreeCommDllFile();
           return FALSE;
       }
       m_rsI2CMasterCurrentReadEx = (func_rsI2CMasterCurrentReadEx)dlsym(m_hCommDll, "I2CMasterCurrentReadEx");
       if(m_rsI2CMasterCurrentReadEx == NULL)
       {
           FreeCommDllFile();
           return FALSE;
       }
       m_rsI2CMasterRead = (func_rsI2CMasterRead)dlsym(m_hCommDll, "I2CMasterRead");
       if(m_rsI2CMasterRead == NULL)
       {
           FreeCommDllFile();
           return FALSE;
       }
       m_rsI2CMasterReadEx = (func_rsI2CMasterReadEx)dlsym(m_hCommDll, "I2CMasterReadEx");
       if(m_rsI2CMasterReadEx == NULL)
       {
           FreeCommDllFile();
           return FALSE;
       }
       m_rsI2CMasterWordRead = (func_rsI2CMasterWordRead)dlsym(m_hCommDll, "I2CMasterWordRead");
       if(m_rsI2CMasterWordRead == NULL)
       {
           FreeCommDllFile();
           return FALSE;
       }
       m_rsI2CMasterWordReadEx = (func_rsI2CMasterWordReadEx)dlsym(m_hCommDll, "I2CMasterWordReadEx");
       if(m_rsI2CMasterWordReadEx == NULL)
       {
           FreeCommDllFile();
           return FALSE;
       }
       m_rsI2CMasterCurrentWrite = (func_rsI2CMasterCurrentWrite)dlsym(m_hCommDll, "I2CMasterCurrentWrite");
       if(m_rsI2CMasterCurrentWrite == NULL)
       {
           FreeCommDllFile();
           return FALSE;
       }
       m_rsI2CMasterCurrentWriteEx = (func_rsI2CMasterCurrentWriteEx)dlsym(m_hCommDll, "I2CMasterCurrentWriteEx");
       if(m_rsI2CMasterCurrentWriteEx == NULL)
       {
           FreeCommDllFile();
           return FALSE;
       }
       m_rsI2CMasterWrite = (func_rsI2CMasterWrite)dlsym(m_hCommDll, "I2CMasterWrite");
       if(m_rsI2CMasterWrite == NULL)
       {
           FreeCommDllFile();
           return FALSE;
       }
       m_rsI2CMasterWriteByte = (func_rsI2CMasterWriteByte)dlsym(m_hCommDll, "I2CMasterWriteByte");
       if(m_rsI2CMasterWriteByte == NULL)
       {
           FreeCommDllFile();
           return FALSE;
       }
       m_rsI2CMasterWriteEx = (func_rsI2CMasterWriteEx)dlsym(m_hCommDll, "I2CMasterWriteEx");
       if(m_rsI2CMasterWriteEx == NULL)
       {
           FreeCommDllFile();
           return FALSE;
       }
       m_rsI2CMasterWordWrite = (func_rsI2CMasterWordWrite)dlsym(m_hCommDll, "I2CMasterWordWrite");
       if(m_rsI2CMasterWordWrite == NULL)
       {
           FreeCommDllFile();
           return FALSE;
       }
       m_rsI2CMasterWordWriteEx = (func_rsI2CMasterWordWriteEx)dlsym(m_hCommDll, "I2CMasterWordWriteEx");
       if(m_rsI2CMasterWordWriteEx == NULL)
       {
           FreeCommDllFile();
           return FALSE;
       }

       m_rsGetUsbDevicePath = (func_rsGetUsbDevicePath)dlsym(m_hCommDll, "GetUsbDevicePath");
       if(m_rsGetUsbDevicePath == NULL)
       {
           FreeCommDllFile();
           return FALSE;
       }

       m_rsSelectUsbByDevicePath = (func_rsSelectUsbByDevicePath)dlsym(m_hCommDll, "SelectUsbByDevicePath");
       if(m_rsSelectUsbByDevicePath == NULL)
       {
           FreeCommDllFile();
           return FALSE;
       }

       m_rsSelectUsbByIndex = (func_rsSelectUsbByIndex)dlsym(m_hCommDll, "SelectUsbByIndex");
       if(m_rsSelectUsbByIndex == NULL)
       {
           FreeCommDllFile();
           return FALSE;
       }

       m_rsReadFlashData = (func_rsReadFlashData)dlsym(m_hCommDll, "ReadFlashData");
       if(m_rsReadFlashData == NULL)
       {
           FreeCommDllFile();
           return FALSE;
       }

       m_rsWriteFlashData = (func_rsWriteFlashData)dlsym(m_hCommDll, "WriteFlashData");
       if(m_rsWriteFlashData == NULL)
       {
           FreeCommDllFile();
           return FALSE;
       }

    m_rsSetCmdLine = (func_rsSetCmdLine)dlsym(m_hCommDll, "SetCmdLine");
    if(m_rsSetCmdLine == NULL)
    {
    	FreeCommDllFile();
    	return FALSE;
    }

//        m_rsGetSpecialCommType = (func_rsGetSpecialCommType)dlsym(m_hCommDll, "GetSpecialCommType");
//        if(m_rsGetSpecialCommType == NULL)
//        {
//            FreeCommDllFile();
//            return FALSE;
//        }
//        m_rsSetSpecialCommType = (func_rsSetSpecialCommType)dlsym(m_hCommDll, "SetSpecialCommType");
//        if(m_rsSetSpecialCommType == NULL)
//        {
//            FreeCommDllFile();
//            return FALSE;
//        }

       m_rsRead32BitRegEx = (func_rsRead32BitRegEx)dlsym(m_hCommDll, "Read32BitRegEx");
       if(m_rsRead32BitRegEx == NULL)
       {
           FreeCommDllFile();
           return FALSE;
       }

       m_rsWrite32BitRegEx = (func_rsWrite32BitRegEx)dlsym(m_hCommDll, "Write32BitRegEx");
       if(m_rsWrite32BitRegEx == NULL)
       {
           FreeCommDllFile();
           return FALSE;
       }

       m_rsRead32BitRegsEx = (func_rsRead32BitRegsEx)dlsym(m_hCommDll, "Read32BitRegsEx");
       if(m_rsRead32BitRegsEx == NULL)
       {
           FreeCommDllFile();
           return FALSE;
       }

       m_rsWrite32BitRegsEx = (func_rsWrite32BitRegsEx)dlsym(m_hCommDll, "Write32BitRegsEx");
       if(m_rsWrite32BitRegsEx == NULL)
       {
           FreeCommDllFile();
           return FALSE;
       }

       m_rsReadDDRRegEx = (func_rsReadDDRRegEx)dlsym(m_hCommDll, "ReadDDRRegEx");
       if(m_rsReadDDRRegEx == NULL)
       {
           FreeCommDllFile();
           return FALSE;
       }

       m_rsWriteDDRRegEx = (func_rsWriteDDRRegEx)dlsym(m_hCommDll, "WriteDDRRegEx");
       if(m_rsWriteDDRRegEx == NULL)
       {
           FreeCommDllFile();
           return FALSE;
       }

       m_rsReadDDRRegsEx = (func_rsReadDDRRegsEx)dlsym(m_hCommDll, "ReadDDRRegsEx");
       if(m_rsReadDDRRegsEx == NULL)
       {
           FreeCommDllFile();
           return FALSE;
       }

       m_rsWriteDDRRegsEx = (func_rsWriteDDRRegsEx)dlsym(m_hCommDll, "WriteDDRRegsEx");
       if(m_rsWriteDDRRegsEx == NULL)
       {
           FreeCommDllFile();
           return FALSE;
       }

       m_rsReadPWM2SPIReg = (func_rsReadPWM2SPIReg)dlsym(m_hCommDll, "ReadPWM2SPIReg");
       if(m_rsReadPWM2SPIReg == NULL)
       {
           FreeCommDllFile();
           return FALSE;
       }

       m_rsWritePWM2SPIReg = (func_rsWritePWM2SPIReg)dlsym(m_hCommDll, "WritePWM2SPIReg");
       if(m_rsWritePWM2SPIReg == NULL)
       {
           FreeCommDllFile();
           return FALSE;
       }

       m_rsReadPWM2SPIDev = (func_rsReadPWM2SPIDev)dlsym(m_hCommDll, "ReadPWM2SPIDev");
       if(m_rsReadPWM2SPIDev == NULL)
       {
           FreeCommDllFile();
           return FALSE;
       }

       m_rsWritePWM2SPIDev = (func_rsWritePWM2SPIDev)dlsym(m_hCommDll, "WritePWM2SPIDev");
       if(m_rsWritePWM2SPIDev == NULL)
       {
           FreeCommDllFile();
           return FALSE;
       }

       m_rsI2CWriteSegment = (func_rsI2CWriteSegment)dlsym(m_hCommDll, "I2CWriteSegment");
       if(m_rsI2CWriteSegment == NULL)
       {
           FreeCommDllFile();
           return FALSE;
       }

       m_rsI2CWriteSegmentEx = (func_rsI2CWriteSegmentEx)dlsym(m_hCommDll, "I2CWriteSegmentEx");
       if(m_rsI2CWriteSegmentEx == NULL)
       {
           FreeCommDllFile();
           return FALSE;
       }

       m_rsI2CReadSegment = (func_rsI2CReadSegment)dlsym(m_hCommDll, "I2CReadSegment");
       if(m_rsI2CReadSegment == NULL)
       {
           FreeCommDllFile();
           return FALSE;
       }

       m_rsI2CReadSegmentEx = (func_rsI2CReadSegmentEx)dlsym(m_hCommDll, "I2CReadSegmentEx");
       if(m_rsI2CReadSegmentEx == NULL)
       {
           FreeCommDllFile();
           return FALSE;
       }

       m_rsAutoEnterIspMode = (func_rsAutoEnterIspMode)dlsym(m_hCommDll, "AutoEnterIspMode");
       if(m_rsAutoEnterIspMode == NULL)
       {
           FreeCommDllFile();
           return FALSE;
       }

       m_rsSetSpecialCommType = (func_rsSetSpecialCommType)dlsym(m_hCommDll, "SetSpecialCommType");
       if(m_rsSetSpecialCommType == NULL)
       {
           FreeCommDllFile();
           return FALSE;
       }

       m_rsGetSpecialCommType = (func_rsGetSpecialCommType)dlsym(m_hCommDll, "GetSpecialCommType");
       if(m_rsGetSpecialCommType == NULL)
       {
           FreeCommDllFile();
           return FALSE;
       }

       return TRUE;
}

void CCpRsComm::FreeCommDllFile()
{

    if(m_hCommDll == NULL)
    {
        return;
    }
    dlclose(m_hCommDll);
    m_hCommDll = NULL;

}

