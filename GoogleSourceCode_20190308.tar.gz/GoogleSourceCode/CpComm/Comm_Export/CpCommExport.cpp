#include "stdafx.h"
#include "CpCommExport.h"

CCpRsComm::CCpRsComm()
{
    m_hCommDll = NULL;
}

CCpRsComm::~CCpRsComm()
{

}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::Initiallize()
{
    if(m_rsInitiallize == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }

    return m_rsInitiallize();
}

// Get current device count, this function must be called after rsInitiallize has been called
WORD CCpRsComm::GetCommCount()
{
    if(m_rsGetCommCount == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }

    return m_rsGetCommCount();
}

STRUCT_ENUM_COMM_ID CCpRsComm::GetCommID()
{
    if(m_rsGetCommID == NULL)
    {
        return _ENUM_COMM_UNKNOWN;
    }

    return m_rsGetCommID();
}

void CCpRsComm::GetCommName(TCHAR* szName, WORD usLength)
{
    if(m_rsGetCommName == NULL)
    {
        return;
    }

    return m_rsGetCommName(szName, usLength);
}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::GetCommFile(STRUCT_COMM_INFO *pstCommVer)
{
    if(m_rsGetCommFile == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }

    return m_rsGetCommFile(pstCommVer);
}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::SetCommByIndex(WORD usCommIndex)
{
    if(m_rsSetCommByIndex == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }

    return m_rsSetCommByIndex(usCommIndex);
}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::SetCommByID(STRUCT_ENUM_COMM_ID enumCommID)
{
    if(m_rsSetCommByID == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }

    return m_rsSetCommByID(enumCommID);
}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::SetDebugSlave(BYTE ucDebugSlave)
{
    if(m_rsSetDebugSlave == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }

    return m_rsSetDebugSlave(ucDebugSlave);
}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::SetIspSlave(BYTE ucIspSlave)
{
    if(m_rsSetIspSlave == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }

    return m_rsSetIspSlave(ucIspSlave);
}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::SetIspContinuousSlave(BYTE ucIspContinuousSlave)
{
    if(m_rsSetIspContinuousSlave == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }

    return m_rsSetIspContinuousSlave(ucIspContinuousSlave);
}

BYTE CCpRsComm::GetDebugSlave()
{
    if(m_rsGetDebugSlave == NULL)
    {
        return 0;
    }

    return m_rsGetDebugSlave();
}

BYTE CCpRsComm::GetIspSlave()
{
    if(m_rsGetIspSlave == NULL)
    {
        return 0;
    }

    return m_rsGetIspSlave();
}

BYTE CCpRsComm::GetIspContinuousSlave()
{
    if(m_rsGetIspContinuousSlave == NULL)
    {
        return 0;
    }

    return m_rsGetIspContinuousSlave();
}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::SetDebugMode(STRUCT_ENUM_DEBUG_TYPE enumDebugType)
{
    if(m_rsSetDebugMode == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }

    return m_rsSetDebugMode(enumDebugType);
}

STRUCT_ENUM_DEBUG_TYPE CCpRsComm::GetDebugMode()
{
    if(m_rsGetDebugMode == NULL)
    {
        return _DEBUG_UNKNOWN;
    }

    return m_rsGetDebugMode();
}
STRUCT_ENUM_ERROR_TYPE CCpRsComm::ReadReg(BYTE ucReg, BYTE* pucValue)
{
    if(m_rsReadReg == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }

    return m_rsReadReg(ucReg, pucValue);
}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::WriteReg(BYTE ucReg, BYTE ucValue)
{
    if(m_rsWriteReg == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }

    return m_rsWriteReg(ucReg, ucValue);
}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::ReadRegs(BYTE ucReg, WORD usLength, LPBYTE pucBuf, STRUCT_ENUM_INC_TYPE enumInc)
{
    if(m_rsReadRegs == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }

    return m_rsReadRegs(ucReg, usLength, pucBuf, enumInc);
}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::WriteRegs(BYTE ucReg, WORD usLength, LPBYTE pucBuf, STRUCT_ENUM_INC_TYPE enumInc)
{
    if(m_rsWriteRegs == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }

    return m_rsWriteRegs(ucReg, usLength, pucBuf, enumInc);
}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::WriteRegBit(BYTE ucReg, BYTE ucAnd, BYTE ucOr)
{
    if(m_rsWriteRegBit == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }

    return m_rsWriteRegBit(ucReg, ucAnd, ucOr);
}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::WritePortRegBit(BYTE ucAddrReg, BYTE ucDataReg, BYTE ucAnd, BYTE ucOr)
{
    if(m_rsWritePortRegBit == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }

    return m_rsWritePortRegBit(ucAddrReg, ucDataReg, ucAnd, ucOr);
}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::ReadRegEx(WORD usReg, BYTE* pucValue)
{
    if(m_rsReadRegEx == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }

    return m_rsReadRegEx(usReg, pucValue);
}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::WriteRegEx(WORD usReg, BYTE ucValue)
{
    if(m_rsWriteRegEx == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }

    return m_rsWriteRegEx(usReg, ucValue);
}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::ReadRegsEx(WORD usReg, WORD usLength, LPBYTE pucBuf, STRUCT_ENUM_INC_TYPE enumInc)
{
    if(m_rsReadRegsEx == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }

    return m_rsReadRegsEx(usReg, usLength, pucBuf, enumInc);
}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::WriteRegsEx(WORD usReg, WORD usLength, LPBYTE pucBuf, STRUCT_ENUM_INC_TYPE enumInc)
{
    if(m_rsWriteRegsEx == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }

    return m_rsWriteRegsEx(usReg, usLength, pucBuf, enumInc);
}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::WriteRegBitEx(WORD usReg, BYTE ucAnd, BYTE ucOr)
{
    if(m_rsWriteRegBitEx == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }

    return m_rsWriteRegBitEx(usReg, ucAnd, ucOr);
}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::WritePortRegBitEx(WORD usAddrReg, WORD usDataReg, BYTE ucAnd, BYTE ucOr)
{
    if(m_rsWritePortRegBitEx == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }

    return m_rsWritePortRegBitEx(usAddrReg, usDataReg, ucAnd, ucOr);
}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::ReadSysDevice(BYTE ucSlave, BYTE ucSub, BYTE ucLength, LPBYTE pucBuf, STRUCT_ENUM_SYS_DEVICE_CMD_TYPE enumCmdType)
{
    if(m_rsReadSysDevice == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }

    return m_rsReadSysDevice(ucSlave, ucSub, ucLength, pucBuf, enumCmdType);
}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::WriteSysDevice(BYTE ucSlave, BYTE ucSub, BYTE ucLength, LPBYTE pucBuf, STRUCT_ENUM_SYS_DEVICE_CMD_TYPE enumCmdType)
{
    if(m_rsWriteSysDevice == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }

    return m_rsWriteSysDevice(ucSlave, ucSub, ucLength, pucBuf, enumCmdType);
}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::ReadWordSysDevice(BYTE ucSlave, WORD usSub, BYTE ucLength, LPBYTE pucBuf, STRUCT_ENUM_SYS_DEVICE_CMD_TYPE enumCmdType)
{
    if(m_rsReadWordSysDevice == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }

    return m_rsReadWordSysDevice(ucSlave, usSub, ucLength, pucBuf, enumCmdType);
}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::WriteWordSysDevice(BYTE ucSlave, WORD usSub, BYTE ucLength, LPBYTE pucBuf, STRUCT_ENUM_SYS_DEVICE_CMD_TYPE enumCmdType)
{
    if(m_rsWriteWordSysDevice == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }

    return m_rsWriteWordSysDevice(ucSlave, usSub, ucLength, pucBuf, enumCmdType);
}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::ScalerStop()
{
    if(m_rsScalerStop == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }

    return m_rsScalerStop();
}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::ScalerRun()
{
    if(m_rsScalerRun == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }

    return m_rsScalerRun();
}
WORD CCpRsComm::GetI2CPageLength()
{
    if(m_rsGetI2CPageLength == NULL)
    {
        return 0;
    }

    return m_rsGetI2CPageLength();
}
WORD CCpRsComm::GetNativePageLength()
{
    if(m_rsGetNativePageLength == NULL)
    {
        return 0;
    }

    return m_rsGetNativePageLength();
}
STRUCT_ENUM_ERROR_TYPE CCpRsComm::I2CWrite(BYTE ucSlave, BYTE ucSub, WORD usLength, const LPBYTE pucBuf)
{
    if(m_rsI2CWrite == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }

    return m_rsI2CWrite(ucSlave, ucSub, usLength, pucBuf);
}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::I2CRead(BYTE ucSlave, BYTE ucSub, WORD usLength, LPBYTE pucBuf)
{
    if(m_rsI2CRead == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }

    return m_rsI2CRead(ucSlave, ucSub, usLength, pucBuf);
}
STRUCT_ENUM_ERROR_TYPE CCpRsComm::I2CWriteByte(BYTE ucSlave, BYTE ucSub, BYTE ucValue)
{
    if(m_rsI2CWriteByte == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }

    return m_rsI2CWriteByte(ucSlave, ucSub, ucValue);
}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::I2CCurrentRead(BYTE ucSlave, WORD usLength, LPBYTE pucBuf)
{
    if(m_rsI2CCurrentRead == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }

    return m_rsI2CCurrentRead(ucSlave, usLength, pucBuf);
}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::I2CWordWrite(BYTE ucSlave, WORD usSub, WORD usLength, const LPBYTE pucBuf)
{
    if(m_rsI2CWordWrite == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }

    return m_rsI2CWordWrite(ucSlave, usSub, usLength, pucBuf);
}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::I2CWordRead(BYTE ucSlave, WORD usSub, WORD usLength, LPBYTE pucBuf)
{
    if(m_rsI2CWordRead == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }

    return m_rsI2CWordRead(ucSlave, usSub, usLength, pucBuf);
}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::I2CWriteEx(BYTE ucSlave, BYTE ucSub, WORD usLength, const LPBYTE pucBuf, STRUCT_ENUM_INC_TYPE enumInc)
{
    if(m_rsI2CWriteEx == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }

    return m_rsI2CWriteEx(ucSlave, ucSub, usLength, pucBuf, enumInc);
}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::I2CReadEx(BYTE ucSlave, BYTE ucSub, WORD usLength, LPBYTE pucBuf, STRUCT_ENUM_INC_TYPE enumInc)
{
    if(m_rsI2CReadEx == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }

    return m_rsI2CReadEx(ucSlave, ucSub, usLength, pucBuf, enumInc);
}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::I2CCurrentReadEx(BYTE ucSlave, WORD usLength, LPBYTE pucBuf)
{
    if(m_rsI2CCurrentReadEx == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }

    return m_rsI2CCurrentReadEx(ucSlave, usLength, pucBuf);
}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::I2CWordWriteEx(BYTE ucSlave, WORD usSub, WORD usLength, const LPBYTE pucBuf, STRUCT_ENUM_INC_TYPE enumInc)
{
    if(m_rsI2CWordWriteEx == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }

    return m_rsI2CWordWriteEx(ucSlave, usSub, usLength, pucBuf, enumInc);
}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::I2CWordReadEx(BYTE ucSlave, WORD usSub, WORD usLength, LPBYTE pucBuf, STRUCT_ENUM_INC_TYPE enumInc)
{
    if(m_rsI2CWordReadEx == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }

    return m_rsI2CWordReadEx(ucSlave, usSub, usLength, pucBuf, enumInc);
}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::AdjustOption()
{
    if(m_rsAdjustOption == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }

    return m_rsAdjustOption();
}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::SetI2CSpeed(WORD usSpeed)
{
    if(m_rsSetI2CSpeed == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }

    return m_rsSetI2CSpeed(usSpeed);
}

WORD CCpRsComm::GetI2CSpeed()
{
    if(m_rsGetI2CSpeed == NULL)
    {
        return 0;
    }

    return m_rsGetI2CSpeed();
}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::SetAuxMode(STRUCT_AUXMODE_STRUCT stAuxMode)
{
    if(m_rsSetAuxMode == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }

    return m_rsSetAuxMode(stAuxMode);
}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::SetWaitingMode(STRUCT_WAITING_STRUCT stWaiting)
{
    if(m_rsSetWaitingMode == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }

    return m_rsSetWaitingMode(stWaiting);
}

STRUCT_WAITING_STRUCT CCpRsComm::GetWaitingMode()
{
    STRUCT_WAITING_STRUCT stWaiting;

    if(m_rsGetWaitingMode == NULL)
    {
        stWaiting.enumWaiting = _WAITING_NONE;
        stWaiting.ulWaitingTime = 0;
        return stWaiting;
    }

    return m_rsGetWaitingMode();
}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::WriteMcuReg(WORD usReg, BYTE ucValue)
{
    if(m_rsWriteMcuReg == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }

    return m_rsWriteMcuReg(usReg, ucValue);
}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::WriteMcuRegBit(WORD usReg, BYTE ucAnd, BYTE ucOr)
{
    if(m_rsWriteMcuRegBit == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }

    return m_rsWriteMcuRegBit(usReg, ucAnd, ucOr);
}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::ReadMcuReg(WORD usReg, BYTE* pucValue)
{
    if(m_rsReadMcuReg == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }

    return m_rsReadMcuReg(usReg, pucValue);
}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::WriteMcuRegs(WORD usReg, WORD usLength, LPBYTE pucBuf, STRUCT_ENUM_INC_TYPE enumInc)
{
    if(m_rsWriteMcuRegs == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }

    return m_rsWriteMcuRegs(usReg, usLength, pucBuf, enumInc);
}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::ReadMcuRegs(WORD usReg, WORD usLength, LPBYTE pucBuf, STRUCT_ENUM_INC_TYPE enumInc)
{
    if(m_rsReadMcuRegs == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }

    return m_rsReadMcuRegs(usReg, usLength, pucBuf, enumInc);
}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::WriteContinuousMcuReg(BYTE ucSub, WORD usLength, LPBYTE pucBuf, STRUCT_ENUM_INC_TYPE enumInc)
{
    if(m_rsWriteContinuousMcuReg == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }

    return m_rsWriteContinuousMcuReg(ucSub, usLength, pucBuf, enumInc);
}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::ReadContinuousMcuReg(BYTE ucSub, WORD usLength, LPBYTE pucBuf, STRUCT_ENUM_INC_TYPE enumInc)
{
    if(m_rsReadContinuousMcuReg == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }

    return m_rsReadContinuousMcuReg(ucSub, usLength, pucBuf, enumInc);
}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::ReleaseDev()
{
    if(m_rsReleaseDev == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }

    return m_rsReleaseDev();
}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::NativeWrite(INT nAddress, WORD usLength, const LPBYTE pucBuf)
{
    if(m_rsNativeWrite == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }

    return m_rsNativeWrite(nAddress, usLength, pucBuf);
}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::NativeRead(INT nAddress, WORD usLength, LPBYTE pucBuf)
{
    if(m_rsNativeRead == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }

    return m_rsNativeRead(nAddress, usLength, pucBuf);
}

void CCpRsComm::SetSettingFilePath(TCHAR* pcSettingFilePath)
{
    if(m_rsSetConfigFilePath == NULL)
    {
        return;
    }

    return m_rsSetConfigFilePath(pcSettingFilePath);
}

void * CCpRsComm::GetDeviceHandler()
{
    if(m_rsGetDeviceHandler == NULL)
    {
        return NULL;
    }

    return m_rsGetDeviceHandler();
}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::ResetFirmware()
{
    if(m_rsResetFirmware == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }

    return m_rsResetFirmware();
}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::EnterIspMode(WORD usRetryTimes)
{
    if(m_rsEnterIspMode == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }

    return m_rsEnterIspMode(usRetryTimes);
}

DWORD CCpRsComm::GetSMBUSDataType()
{
    if(m_rsGetSMBUSDataType == NULL)
    {
        return _ENUM_SMBUS_DATA_TYPE_UNKNOWN;
    }

    return m_rsGetSMBUSDataType();
}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::SetSMBUSDataType(DWORD ulSMBUSDataType)
{
    if(m_rsSetSMBUSDataType == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }

    return m_rsSetSMBUSDataType(ulSMBUSDataType);
}
BYTE CCpRsComm::GetDeviceCount()
{
    if(m_rsGetDeviceCount == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }

    return m_rsGetDeviceCount();
}
STRUCT_ENUM_ERROR_TYPE CCpRsComm::RemoveDevice()
{
    if(m_rsRemoveDevice == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }

    return m_rsRemoveDevice();
}
STRUCT_ENUM_ERROR_TYPE CCpRsComm::AutoDetectSlaveAddr()
{
    if(m_rsAutoDetectSlaveAddr == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }

    return m_rsAutoDetectSlaveAddr();
}
STRUCT_ENUM_ERROR_TYPE CCpRsComm::DDCCIWrite(BYTE ucSlave, BYTE ucSub, BYTE ucLength, const LPBYTE pucBuf)
{
    if(m_rsDDCCIWrite == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }
    return m_rsDDCCIWrite(ucSlave, ucSub, ucLength, pucBuf);

}
STRUCT_ENUM_ERROR_TYPE CCpRsComm::DDCCIRead(BYTE ucSlave, BYTE ucSub, BYTE ucLength, LPBYTE pucBuf)
{
    if(m_rsDDCCIRead == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }
    return m_rsDDCCIRead(ucSlave, ucSub, ucLength, pucBuf);

}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::SetFTDIGetAck(BOOL bEnable)
{
    if(m_rsSetFTDIGetAck == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }
    return m_rsSetFTDIGetAck(bEnable);
}
BOOL CCpRsComm::GetFTDIGetAckStatus()
{
    if(m_rsGetFTDIGetAckStatus == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }
    return m_rsGetFTDIGetAckStatus();
}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::I2CMasterInitial(STRUCT_ENUM_IIC_MASTER_SPEED enumI2cMasterSpeed)
{
    if(m_rsI2CMasterInitial == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }
    return m_rsI2CMasterInitial(enumI2cMasterSpeed);
}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::I2CMasterCurrentRead(BYTE ucSlave, WORD usLength, LPBYTE pucBuf)
{
    if(m_rsI2CMasterCurrentRead == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }
    return m_rsI2CMasterCurrentRead(ucSlave, usLength, pucBuf);
}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::I2CMasterCurrentReadEx(BYTE ucSlave, WORD usLength, LPBYTE pucBuf)
{
    if(m_rsI2CMasterCurrentRead == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }
    return m_rsI2CMasterCurrentRead(ucSlave, usLength, pucBuf);
}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::I2CMasterRead(BYTE ucSlave, BYTE ucSub, WORD usLength, LPBYTE pucBuf)
{
    if(m_rsI2CMasterRead == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }
    return m_rsI2CMasterRead(ucSlave, ucSub, usLength, pucBuf);
}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::I2CMasterReadEx(BYTE ucSlave, BYTE ucSub, WORD usLength, LPBYTE pucBuf, STRUCT_ENUM_INC_TYPE enumInc)
{
    if(m_rsI2CMasterReadEx == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }
    return m_rsI2CMasterReadEx(ucSlave, ucSub, usLength, pucBuf, enumInc);
}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::I2CMasterWordRead(BYTE ucSlave, WORD usSub, WORD usLength, LPBYTE pucBuf)
{
    if(m_rsI2CMasterWordRead == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }
    return m_rsI2CMasterWordRead(ucSlave, usSub, usLength, pucBuf);
}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::I2CMasterWordReadEx(BYTE ucSlave, WORD usSub, WORD usLength, LPBYTE pucBuf, STRUCT_ENUM_INC_TYPE enumInc)
{
    if(m_rsI2CMasterWordReadEx == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }
    return m_rsI2CMasterWordReadEx(ucSlave, usSub, usLength, pucBuf, enumInc);
}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::I2CMasterCurrentWrite(BYTE ucSlave, WORD usLength, const LPBYTE pucBuf)
{
    if(m_rsI2CMasterCurrentWrite == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }
    return m_rsI2CMasterCurrentWrite(ucSlave, usLength, pucBuf);
}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::I2CMasterCurrentWriteEx(BYTE ucSlave, WORD usLength, const LPBYTE pucBuf)
{
    if(m_rsI2CMasterCurrentWriteEx == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }
    return m_rsI2CMasterCurrentWriteEx(ucSlave, usLength, pucBuf);
}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::I2CMasterWrite(BYTE ucSlave, BYTE ucSub, WORD usLength, const LPBYTE pucBuf)
{
    if(m_rsI2CMasterWrite == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }
    return m_rsI2CMasterWrite(ucSlave, ucSub, usLength, pucBuf);
}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::I2CMasterWriteByte(BYTE ucSlave, BYTE ucSub, BYTE ucValue)
{
    if(m_rsI2CMasterWriteByte == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }
    return m_rsI2CMasterWriteByte(ucSlave, ucSub, ucValue);
}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::I2CMasterWriteEx(BYTE ucSlave, BYTE ucSub, WORD usLength, const LPBYTE pucBuf, STRUCT_ENUM_INC_TYPE enumInc)
{
    if(m_rsI2CMasterWriteEx == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }
    return m_rsI2CMasterWriteEx(ucSlave, ucSub, usLength, pucBuf, enumInc);
}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::I2CMasterWordWrite(BYTE ucSlave, WORD usSub, WORD usLength, const LPBYTE pucBuf)
{
    if(m_rsI2CMasterWordWrite == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }
    return m_rsI2CMasterWordWrite(ucSlave, usSub, usLength, pucBuf);
}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::I2CMasterWordWriteEx(BYTE ucSlave, WORD usSub, WORD usLength, const LPBYTE pucBuf, STRUCT_ENUM_INC_TYPE enumInc)
{
    if(m_rsI2CMasterWordWriteEx == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }
    return m_rsI2CMasterWordWriteEx(ucSlave, usSub, usLength, pucBuf, enumInc);
}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::GetUsbDevicePath(BYTE ucIndex, TCHAR* pcszDevicePath)
{
    if(m_rsGetUsbDevicePath == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }
    return m_rsGetUsbDevicePath(ucIndex, pcszDevicePath);
}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::SelectUsbByDevicePath(TCHAR* pcszDevicePath)
{
    if(m_rsSelectUsbByDevicePath == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }
    return m_rsSelectUsbByDevicePath(pcszDevicePath);

}
STRUCT_ENUM_ERROR_TYPE CCpRsComm::SelectUsbByIndex(BYTE ucIndex)
{
    if(m_rsSelectUsbByIndex == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }
    return m_rsSelectUsbByIndex(ucIndex);

}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::WriteFlashData(DWORD ulFlashAddr, WORD usLen, LPBYTE pucBuf)
{
    if(m_rsWriteFlashData == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }
    return m_rsWriteFlashData(ulFlashAddr, usLen, pucBuf);
}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::ReadFlashData(DWORD ulFlashAddr, WORD usLen, LPBYTE pucBuf)
{
    if(m_rsReadFlashData == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }
    return m_rsReadFlashData(ulFlashAddr, usLen, pucBuf);
}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::DebugMessageEventStart(WORD usFilterPro, LPBYTE pucBuf)
{
    if(m_rsDebugMessageEventStart == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }
    return m_rsDebugMessageEventStart(usFilterPro, pucBuf);

}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::DebugMessageEventFinish(LPBYTE pucBuf)
{
    if(m_rsDebugMessageEventFinish == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }
    return m_rsDebugMessageEventFinish(pucBuf);

}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::DebugMessageStart(LPBYTE pucBuf)
{
    if(m_rsDebugMessageStart == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }
    return m_rsDebugMessageStart(pucBuf);

}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::DebugMessageEnd(LPBYTE pucBuf)
{
    if(m_rsDebugMessageEnd == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }
    return m_rsDebugMessageEnd(pucBuf);

}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::DebugMessageGetValue(LPBYTE pucBuf)
{
    if(m_rsDebugMessageGetValue == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }
    return m_rsDebugMessageGetValue(pucBuf);

}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::DebugMessageGetString(WORD usLen, LPBYTE pucBuf)
{
    if(m_rsDebugMessageGetString == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }
    return m_rsDebugMessageGetString(usLen, pucBuf);
}

void CCpRsComm::SetCmdLine(TCHAR *pcCmd)
{
    if(m_rsSetCmdLine == NULL)
    {
        return;
    }
    return m_rsSetCmdLine(pcCmd);
}

// STRUCT_ENUM_SPECIAL_COMM_TYPE CCpRsComm::GetSpecialCommType()
// {
//     if(m_rsGetSpecialCommType == NULL)
//     {
//         return _ENUM_SPECIAL_COMM_START;
//     }
//     return m_rsGetSpecialCommType();
// 
// }
// 
// STRUCT_ENUM_ERROR_TYPE CCpRsComm::SetSpecialCommType(STRUCT_ENUM_SPECIAL_COMM_TYPE enumSpecialCommType)
// {
//     if(m_rsSetSpecialCommType == NULL)
//     {
//         return _ERROR_COMM_NO_INITIAL;
//     }
//     return m_rsSetSpecialCommType(enumSpecialCommType);
// }
// 
STRUCT_ENUM_ERROR_TYPE CCpRsComm::Read32BitRegEx(DWORD ulReg, DWORD* pulValue)
{
    if(m_rsRead32BitRegEx == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }
    return m_rsRead32BitRegEx(ulReg, pulValue);

}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::Write32BitRegEx(DWORD ulReg, DWORD ulValue)
{
    if(m_rsWrite32BitRegEx == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }
    return m_rsWrite32BitRegEx(ulReg, ulValue);

}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::Read32BitRegsEx(DWORD ulReg, WORD usLength, LPDWORD pulBuf, STRUCT_ENUM_INC_TYPE enumInc)
{
    if(m_rsRead32BitRegsEx == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }
    return m_rsRead32BitRegsEx(ulReg, usLength, pulBuf, enumInc);

}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::Write32BitRegsEx(DWORD ulReg, WORD usLength, LPDWORD pulBuf, STRUCT_ENUM_INC_TYPE enumInc)
{
    if(m_rsWrite32BitRegsEx == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }
    return m_rsWrite32BitRegsEx(ulReg, usLength, pulBuf, enumInc);

}


STRUCT_ENUM_ERROR_TYPE CCpRsComm::ReadDDRRegEx(DWORD ulReg, DWORD* pulValue)
{
    if(m_rsReadDDRRegEx == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }
    return m_rsReadDDRRegEx(ulReg, pulValue);

}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::WriteDDRRegEx(DWORD ulReg, DWORD ulValue)
{
    if(m_rsWriteDDRRegEx == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }

    return m_rsWriteDDRRegEx(ulReg, ulValue);
}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::ReadDDRRegsEx(DWORD ulReg, WORD usLength, LPDWORD pulBuf, STRUCT_ENUM_INC_TYPE enumInc)
{
    if(m_rsReadDDRRegsEx == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }

    return m_rsReadDDRRegsEx(ulReg, usLength, pulBuf, enumInc);
}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::WriteDDRRegsEx(DWORD ulReg, WORD usLength, LPDWORD pulBuf, STRUCT_ENUM_INC_TYPE enumInc)
{
    if(m_rsWriteDDRRegsEx == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }

    return m_rsWriteDDRRegsEx(ulReg, usLength, pulBuf, enumInc);
}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::ReadPWM2SPIReg(BYTE ucDevIndex, BYTE ucRegStartAddr, BYTE ucLength, BYTE *pucBuf)
{
    if(m_rsReadPWM2SPIReg == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }

    return m_rsReadPWM2SPIReg(ucDevIndex, ucRegStartAddr, ucLength, pucBuf);
}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::WritePWM2SPIReg(BYTE ucDevIndex, BYTE ucRegStartAddr, BYTE ucLength, BYTE *pucBuf)
{
    if(m_rsWritePWM2SPIReg == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }

    return m_rsWritePWM2SPIReg(ucDevIndex, ucRegStartAddr, ucLength, pucBuf);
}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::ReadPWM2SPIDev(BYTE ucDevIndex, BYTE ucPwmStartIndex, BYTE ucPwmNum, WORD *pusBuf)
{
    if(m_rsReadPWM2SPIDev == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }

    return m_rsReadPWM2SPIDev(ucDevIndex, ucPwmStartIndex, ucPwmNum, pusBuf);
}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::WritePWM2SPIDev(BYTE ucDevIndex, BYTE ucPwmStartIndex, BYTE ucPwmNum, WORD *pusBuf)
{
    if(m_rsWritePWM2SPIDev == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }

    return m_rsWritePWM2SPIDev(ucDevIndex, ucPwmStartIndex, ucPwmNum, pusBuf);
}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::I2CWriteSegment(BYTE ucSegSlave, BYTE ucSegAddr, BYTE ucSlave, BYTE ucSub, WORD usLength, const LPBYTE pucBuf)
{
    if(m_rsI2CWriteSegment == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }

    return m_rsI2CWriteSegment(ucSegSlave, ucSegAddr, ucSlave, ucSub, usLength, pucBuf);
}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::I2CWriteSegmentEx(BYTE ucSegSlave, BYTE ucSegAddr, BYTE ucSlave, BYTE ucSub, WORD usLength, const LPBYTE pucBuf, STRUCT_ENUM_INC_TYPE enumInc)
{
    if(m_rsI2CWriteSegmentEx == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }

    return m_rsI2CWriteSegmentEx(ucSegSlave, ucSegAddr, ucSlave, ucSub, usLength, pucBuf, enumInc);
}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::I2CReadSegment(BYTE ucSegSlave, BYTE ucSegAddr, BYTE ucSlave, BYTE ucSub, WORD usLength, const LPBYTE pucBuf)
{
    if(m_rsI2CReadSegment == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }

    return m_rsI2CReadSegment(ucSegSlave, ucSegAddr, ucSlave, ucSub, usLength, pucBuf);
}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::I2CReadSegmentEx(BYTE ucSegSlave, BYTE ucSegAddr, BYTE ucSlave, BYTE ucSub, WORD usLength, const LPBYTE pucBuf, STRUCT_ENUM_INC_TYPE enumInc)
{
    if(m_rsI2CReadSegmentEx == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }

    return m_rsI2CReadSegmentEx(ucSegSlave, ucSegAddr, ucSlave, ucSub, usLength, pucBuf, enumInc);
}

STRUCT_ENUM_ERROR_TYPE CCpRsComm::AutoEnterIspMode(WORD usRetryTimes)
{
    if(m_rsAutoEnterIspMode == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }
    return m_rsAutoEnterIspMode(usRetryTimes);
}

STRUCT_ENUM_SPECIAL_COMM_TYPE CCpRsComm::GetSpecialCommType()
{
    if(m_rsGetSpecialCommType == NULL)
    {
        return _ENUM_SPECIAL_COMM_NORMAL;
    }
    return m_rsGetSpecialCommType();
}
STRUCT_ENUM_ERROR_TYPE CCpRsComm::SetSpecialCommType(STRUCT_ENUM_SPECIAL_COMM_TYPE enumSpecialCommType)
{
    if(m_rsSetSpecialCommType == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }
    return m_rsSetSpecialCommType(enumSpecialCommType);
}

