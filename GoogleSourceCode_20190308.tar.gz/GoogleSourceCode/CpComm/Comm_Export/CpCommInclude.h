/********************************************************************************/
/*   The  Software  is  proprietary,  confidential,  and  valuable to Realsil   */
/*   Semiconductor  Corporation  ("Realsil").  All  rights, including but not   */
/*   limited  to  copyrights,  patents,  trademarks, trade secrets, mask work   */
/*   rights, and other similar rights and interests, are reserved to Realsil.   */
/*   Without  prior  written  consent  from  Realsil,  copying, reproduction,   */
/*   modification,  distribution,  or  otherwise  is strictly prohibited. The   */
/*   Software  shall  be  kept  strictly  in  confidence,  and  shall  not be   */
/*   disclosed to or otherwise accessed by any third party.                     */
/*   c<2003> - <2014>                                                           */
/*   The Software is provided "AS IS" without any warranty of any kind,         */
/*   express, implied, statutory or otherwise.                                  */
/********************************************************************************/

#ifndef _COMM_INCLUDE_H_
#define _COMM_INCLUDE_H_
#include "../../Tool_Common/RsDataType.h"

// Auto increase type for read/write register
typedef enum
{
    _INCTYPE_START = 0,
    _INCTYPE_NONE = _INCTYPE_START,
    _INCTYPE_AUTO,
    _INCTYPE_END,
    //To resolve transfer parameter error when use comm.dll in BCB. 
    //because sizeof(enum) = 4bytes in VC, sizeof(enum) = 1bytes in BCB(Default)   
    _INCTYPE_FINIAL = 0xFFFFFFFF
}STRUCT_ENUM_INC_TYPE;

// Debug mode type
typedef enum
{
    _DEBUG_START = 0,
    _DEBUG_UNKNOWN = _DEBUG_START,
    // Debug by FW
    _DEBUG_DEBUG,
    // Debug by isp mode
    _DEBUG_ISP,
    _DEBUG_XDATA,
    _DEBUG_STEPTRACE,
    _DEBUG_NEW_XDATA,
    _DEBUG_END,
    //To resolve transfer parameter error when use comm.dll in BCB. 
    //because sizeof(enum) = 4bytes in VC, sizeof(enum) = 1bytes in BCB(Default)   
    _DEBUG_FINIAL = 0xFFFFFFFF

}STRUCT_ENUM_DEBUG_TYPE;

// Read/Write System Device Cmd Type
typedef enum
{
    _SYS_DEVICE_CMD_START = 0,
    _SYS_DEVICE_CMD_DEFAULT = _SYS_DEVICE_CMD_START,
    _SYS_DEVICE_CMD_SPECIAL_FOR_PINSHARE_VERIFY,
    _SYS_DEVICE_CMD_END
}STRUCT_ENUM_SYS_DEVICE_CMD_TYPE;

typedef struct
{
    TCHAR strName[_MAX_PATH];
    TCHAR cszCommFile[_MAX_PATH];
}STRUCT_COMM_INFO;

typedef enum
{
    _ENUM_COMM_START = 0,
    _ENUM_COMM_UNKNOWN = _ENUM_COMM_START,
    _ENUM_COMM_AUX,
    _ENUM_COMM_SMBUS,
    _ENUM_COMM_REALTEKUSB,
    _ENUM_COMM_FTDIUSB,
    _ENUM_COMM_GFXI2C,
    _ENUM_COMM_USBHUBI2C,
    _ENUM_COMM_TYPECI2C,
    _ENUM_COMM_TYPECUSB,
	_ENUM_COMM_GLHUBI2C,
	_ENUM_COMM_VIAHUBI2C,
    _ENUM_COMM_LINUXDEVI2C,
    _ENUM_COMM_END,
    //To resolve transfer parameter error when use comm.dll in BCB. 
    //because sizeof(enum) = 4bytes in VC, sizeof(enum) = 1bytes in BCB(Default)   
    _ENUM_COMM_FINIAL = 0xFFFFFFFF
}STRUCT_ENUM_COMM_ID;

// Waiting mode type
typedef enum
{
    _WAITING_START = 0,
    _WAITING_NONE = _WAITING_START,
    _WAITING_POLLING,
    _WAITING_DELAY,
    _WAITING_END,
    //To resolve transfer parameter error when use comm.dll in BCB. 
    //because sizeof(enum) = 4bytes in VC, sizeof(enum) = 1bytes in BCB(Default)   
    _WAITING_FINIAL = 0xFFFFFFFF
}STRUCT_ENUM_WAITING_TYPE;

typedef struct  
{
    STRUCT_ENUM_WAITING_TYPE enumWaiting;
    DWORD ulWaitingTime;
}STRUCT_WAITING_STRUCT;

typedef enum
{
    _ENUM_AUX_NONE = 0,
    _ENUM_AUX_SNIFFER,
    _ENUM_AUX_FPGA,
    //To resolve transfer parameter error when use comm.dll in BCB. 
    //because sizeof(enum) = 4bytes in VC, sizeof(enum) = 1bytes in BCB(Default)   
    _ENUM_AUX_FINIAL = 0xFFFFFFFF
}STRUCT_ENUM_AUX_MODE;

typedef struct  
{
    STRUCT_ENUM_AUX_MODE enumAuxMode;
    DWORD ulAuxPollingTime;
}STRUCT_AUXMODE_STRUCT;


// Communication type
typedef enum
{
    _ENUM_SMBUS_DATA_TYPE_START = 0,
    _ENUM_SMBUS_DATA_TYPE_UNKNOWN = _ENUM_SMBUS_DATA_TYPE_START,
    _ENUM_SMBUS_NORMAL_DATA_TYPE = 1, // normal write,don't Change define for current code
    _ENUM_SMBUS_BLOCK_DATA_TYPE = 1 << 1, // block write
    _ENUM_SMBUS_NORMAL_DATA_TYPE_READ = 1 << 2,
    _ENUM_SMBUS_BLOCK_DATA_TYPE_READ = 1 << 3,
    _ENUM_SMBUS_BLOCK_DATA_TYPE_I2C_READ = 1 << 4,
    _ENUM_SMBUS_BLOCK_DATA_TYPE_I2C_WRITE = 1 << 5, // block write
    //To resolve transfer parameter error when use comm.dll in BCB. 
    //because sizeof(enum) = 4bytes in VC, sizeof(enum) = 1bytes in BCB(Default)   
    _ENUM_SMBUS_DATA_TYPE_FINIAL = 0xFFFFFFFF
}STRUCT_ENUM_SMBUS_DATA_TYPE;

typedef struct 
{
    BYTE ucIspSlave;
    BYTE ucIspContinuousSlave;
    BYTE ucDebugSlave;
}STRUCT_SCALER_SLAVE_ADDR_GROUP;

const WORD US_SCALER_SLAVE_ADDR_AUTO_DEV = 4;
const STRUCT_SCALER_SLAVE_ADDR_GROUP ST_SLAVE_AUTO_DEV[US_SCALER_SLAVE_ADDR_AUTO_DEV]=
{
    {0x94, 0x96, 0x6A},
    {0x64, 0x64, 0x68},
    {0x54, 0x56, 0x58},
    {0xFC, 0xFE, 0x6A},
};

const WORD US_SCALER_SLAVE_ADDR_GROUP_COUNT = 3;
const STRUCT_SCALER_SLAVE_ADDR_GROUP ST_SCALER_SLAVE_ADRR[US_SCALER_SLAVE_ADDR_GROUP_COUNT]=
{
    {0x94, 0x96, 0x6A},
    {0x64, 0x64, 0x68},
    {0x54, 0x56, 0x58},
};

//////////////////////////////////////////////////////////////////////////
// Hw I2C Master
//////////////////////////////////////////////////////////////////////////
//--------------------------------------------------
// Definitions of Hardware IIC
//--------------------------------------------------
#define _HW_IIC_READ_PAGE_LEN                 24
#define _HW_IIC_WRITE_PAGE_LEN                256
#define _HW_IIC_WRITE_PRE_DATA_LEN            16

#define _READ                                 1
#define _WRITE                                0

//--------------------------------------------------
// HW IIC Speed List
//--------------------------------------------------
typedef enum STRUCT_ENUM_IIC_MASTER_SPEED
{
    _ENUM_IIC_MASTER_SPEED_100K = 0,
    _ENUM_IIC_MASTER_SPEED_400K,
    _ENUM_IIC_MASTER_SPEED_100K_TRANS,
    _ENUM_IIC_MASTER_SPEED_75K_TRANS,
    _ENUM_IIC_MASTER_SPEED_45K_TRANS,
}STRUCT_ENUM_IIC_MASTER_SPEED;

#define _HW_IIC_FTPC                        0x03 // 3
#define _HW_IIC_FD10_14318K                 0x01 // 1
#define _HW_IIC_FD10_28000K                 0x02 // 2

//--------------------------------------------------
// Enumerations of System Clock
//--------------------------------------------------
typedef enum STRUCT_ENUM_CLK_SEL_TYPE
{
    _EXT_XTAL_CLK = 0,
    _IOSC_CLK,
    _M2PLL_CLK,
    _ECBUS_CLK,
    _LC_TANK_CLK,
}STRUCT_ENUM_CLK_SEL_TYPE;

typedef enum STRUCT_ENUM_SUBADDR_TYPE
{
    _SUBADDR_START = 0,
    _SUBADDR_CURRENT = _SUBADDR_START,
    _SUBADDR_BYTE,
    _SUBADDR_WORD,
    _SUBADDR_END,
}STRUCT_ENUM_SUBADDR_TYPE;

typedef enum STRUCT_ENUM_SPECIAL_COMM_TYPE
{
    _ENUM_SPECIAL_COMM_START = 0,
    _ENUM_SPECIAL_COMM_NORMAL = _ENUM_SPECIAL_COMM_START,
    _ENUM_SPECIAL_COMM_IICMASTER,
    _ENUM_SPECIAL_COMM_END,
}STRUCT_ENUM_SPECIAL_COMM_TYPE;

#endif // End of #ifndef _COMM_INCLUDE_H_

