/********************************************************************************/
/*   The  Software  is  proprietary,  confidential,  and  valuable to Realsil   */
/*   Semiconductor  Corporation  ("Realsil").  All  rights, including but not   */
/*   limited  to  copyrights,  patents,  trademarks, trade secrets, mask work   */
/*   rights, and other similar rights and interests, are reserved to Realsil.   */
/*   Without  prior  written  consent  from  Realsil,  copying, reproduction,   */
/*   modification,  distribution,  or  otherwise  is strictly prohibited. The   */
/*   Software  shall  be  kept  strictly  in  confidence,  and  shall  not be   */
/*   disclosed to or otherwise accessed by any third party.                     */
/*   c<2003> - <2014>                                                           */
/*   The Software is provided "AS IS" without any warranty of any kind,         */
/*   express, implied, statutory or otherwise.                                  */
/********************************************************************************/

#ifndef _COMM_EXPORT_H_
#define _COMM_EXPORT_H_
#include "CpCommInclude.h"
#include "../../Tool_Common/RsCommon/ErrorDefine.h"

//////////////////////////////////////////////////////////////////////////
// struct define
//////////////////////////////////////////////////////////////////////////
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsInitiallize)();
// rsGetCommCount: 
// Get current device count, this function must be called after rsInitiallize has been called
typedef WORD(*func_rsGetCommCount)();
typedef STRUCT_ENUM_COMM_ID(*func_rsGetCommID)();
typedef void(*func_rsGetCommName)(TCHAR* szName, WORD usLength);
typedef void(*func_rsGetAllCommName)(TCHAR pcNames[][256]);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsGetCommFile)(STRUCT_COMM_INFO *stCommVer);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsSetCommByIndex)(WORD usCommIndex);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsSetCommByID)(STRUCT_ENUM_COMM_ID enumCommID);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsSetDebugSlave)(BYTE ucDebugSlave);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsSetIspSlave)(BYTE ucIspSlave);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsSetIspContinuousSlave)(BYTE ucIspContinuousSlave);
typedef BYTE(*func_rsGetDebugSlave)();
typedef BYTE(*func_rsGetIspSlave)();
typedef BYTE(*func_rsGetIspContinuousSlave)();
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsSetDebugMode)(STRUCT_ENUM_DEBUG_TYPE enumDebugType);
typedef STRUCT_ENUM_DEBUG_TYPE(*func_rsGetDebugMode)();

typedef STRUCT_ENUM_ERROR_TYPE(*func_rsReadReg)(BYTE ucReg, BYTE* pucValue);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsWriteReg)(BYTE ucReg, BYTE ucValue);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsReadRegs)(BYTE ucReg, WORD usLength, LPBYTE pucBuf, STRUCT_ENUM_INC_TYPE enumInc);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsWriteRegs)(BYTE ucReg, WORD usLength, LPBYTE pucBuf, STRUCT_ENUM_INC_TYPE enumInc);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsWriteRegBit)(BYTE ucReg, BYTE ucAnd, BYTE ucOr);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsWritePortRegBit)(BYTE ucAddrReg, BYTE ucDataReg, BYTE ucAnd, BYTE ucOr);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsReadRegEx)(WORD usReg, BYTE* pucValue);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsWriteRegEx)(WORD usReg, BYTE ucValue);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsReadRegsEx)(WORD usReg, WORD usLength, LPBYTE pucBuf, STRUCT_ENUM_INC_TYPE enumInc);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsWriteRegsEx)(WORD usReg, WORD usLength, LPBYTE pucBuf, STRUCT_ENUM_INC_TYPE enumInc);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsWriteRegBitEx)(WORD usReg, BYTE ucAnd, BYTE ucOr);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsWritePortRegBitEx)(WORD usAddrReg, WORD usDataReg, BYTE ucAnd, BYTE ucOr);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsReadSysDevice)(BYTE ucSlave, BYTE ucSub, BYTE ucLength, LPBYTE pucBuf, STRUCT_ENUM_SYS_DEVICE_CMD_TYPE enumCmdType);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsWriteSysDevice)(BYTE ucSlave, BYTE ucSub, BYTE ucLength, LPBYTE pucBuf, STRUCT_ENUM_SYS_DEVICE_CMD_TYPE enumCmdType);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsReadWordSysDevice)(BYTE ucSlave, WORD usSub, BYTE ucLength, LPBYTE pucBuf, STRUCT_ENUM_SYS_DEVICE_CMD_TYPE enumCmdType);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsWriteWordSysDevice)(BYTE ucSlave, WORD usSub, BYTE ucLength, LPBYTE pucBuf, STRUCT_ENUM_SYS_DEVICE_CMD_TYPE enumCmdType);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsScalerStop)();
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsScalerRun)();
typedef WORD(*func_rsGetI2CPageLength)();
typedef WORD(*func_rsGetNativePageLength)();
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsI2CWrite)(BYTE ucSlave, BYTE ucSub, WORD usLength, const LPBYTE pucBuf);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsI2CRead)(BYTE ucSlave, BYTE ucSub, WORD usLength, LPBYTE pucBuf);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsI2CWriteByte)(BYTE ucSlave, BYTE ucSub, BYTE ucValue);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsI2CCurrentRead)(BYTE ucSlave, WORD usLength, LPBYTE pucBuf);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsI2CWordWrite)(BYTE ucSlave, WORD usSub, WORD usLength, const LPBYTE pucBuf);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsI2C2SubWrite)(BYTE ucSlave, BYTE ucSub0, BYTE ucSub1, WORD usLength, const LPBYTE pucBuf);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsI2CWordRead)(BYTE ucSlave, WORD usSub, WORD usLength, LPBYTE pucBuf);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsI2C2SubRead)(BYTE ucSlave, BYTE ucSub0, BYTE ucSub1, WORD usLength, LPBYTE pucBuf);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsI2CWriteEx)(BYTE ucSlave, BYTE ucSub, WORD usLength, const LPBYTE pucBuf, STRUCT_ENUM_INC_TYPE enumInc);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsI2CReadEx)(BYTE ucSlave, BYTE ucSub, WORD usLength, LPBYTE pucBuf, STRUCT_ENUM_INC_TYPE enumInc);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsI2CCurrentReadEx)(BYTE ucSlave, WORD usLength, LPBYTE pucBuf);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsI2CWordWriteEx)(BYTE ucSlave, WORD usSub, WORD usLength, const LPBYTE pucBuf, STRUCT_ENUM_INC_TYPE enumInc);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsI2C2SubWriteEx)(BYTE ucSlave, BYTE ucSub0, BYTE ucSub1, WORD usLength, const LPBYTE pucBuf, STRUCT_ENUM_INC_TYPE enumInc);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsI2CWordReadEx)(BYTE ucSlave, WORD usSub, WORD usLength, LPBYTE pucBuf, STRUCT_ENUM_INC_TYPE enumInc);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsI2C2SubReadEx)(BYTE ucSlave, BYTE ucSub0, BYTE ucSub1, WORD usLength, LPBYTE pucBuf, STRUCT_ENUM_INC_TYPE enumInc);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsAdjustOption)();
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsSetI2CSpeed)(WORD usSpeed);
typedef WORD(*func_rsGetI2CSpeed)();
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsSetAuxMode)(STRUCT_AUXMODE_STRUCT stAuxMode);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsSetWaitingMode)(STRUCT_WAITING_STRUCT stWaiting);
typedef STRUCT_WAITING_STRUCT(*func_rsGetWaitingMode)();
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsWriteMcuReg)(WORD usReg, BYTE ucValue);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsWriteMcuRegBit)(WORD usReg, BYTE ucAnd, BYTE ucOr);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsReadMcuReg)(WORD usReg, BYTE* pucValue);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsWriteMcuRegs)(WORD usReg, WORD usLength, LPBYTE pucBuf, STRUCT_ENUM_INC_TYPE enumInc);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsReadMcuRegs)(WORD usReg, WORD usLength, LPBYTE pucBuf, STRUCT_ENUM_INC_TYPE enumInc);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsWriteContinuousMcuReg)(BYTE ucSub, WORD usLength, LPBYTE pucBuf, STRUCT_ENUM_INC_TYPE enumInc);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsReadContinuousMcuReg)(BYTE ucSub, WORD usLength, LPBYTE pucBuf, STRUCT_ENUM_INC_TYPE enumInc);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsReleaseDev)();
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsNativeWrite)(INT nAddress, WORD usLength, const LPBYTE pucBuf);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsNativeRead)(INT nAddress, WORD usLength, LPBYTE pucBuf);
typedef void(*func_rsSetConfigFilePath)(TCHAR *pcConfigFilePath);
typedef void * (*func_rsGetDeviceHandler)();
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsResetFirmware)();
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsEnterIspMode)(WORD usRetryTimes);
typedef DWORD(*func_rsGetSMBUSDataType)();
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsSetSMBUSDataType)(DWORD ulSMBUSDataType);
typedef BYTE(*func_rsGetDeviceCount)();
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsRemoveDevice)();
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsAutoDetectSlaveAddr)();
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsDDCCIWrite)(BYTE ucSlave, BYTE ucSub, BYTE ucLength, const LPBYTE pucBuf);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsDDCCIRead)(BYTE ucSlave, BYTE ucSub, BYTE ucLength, LPBYTE pucBuf);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsSetFTDIGetAck)(BOOL bEnable);
typedef BOOL(*func_rsGetFTDIGetAckStatus)();

typedef STRUCT_ENUM_ERROR_TYPE(*func_rsI2CMasterInitial)(STRUCT_ENUM_IIC_MASTER_SPEED enumI2cMasterSpeed);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsI2CMasterCurrentRead)(BYTE ucSlave, WORD usLength, LPBYTE pucBuf);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsI2CMasterCurrentReadEx)(BYTE ucSlave, WORD usLength, LPBYTE pucBuf);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsI2CMasterRead)(BYTE ucSlave, BYTE ucSub, WORD usLength, LPBYTE pucBuf);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsI2CMasterReadEx)(BYTE ucSlave, BYTE ucSub, WORD usLength, LPBYTE pucBuf, STRUCT_ENUM_INC_TYPE enumInc);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsI2CMasterWordRead)(BYTE ucSlave, WORD usSub, WORD usLength, LPBYTE pucBuf);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsI2CMasterWordReadEx)(BYTE ucSlave, WORD usSub, WORD usLength, LPBYTE pucBuf, STRUCT_ENUM_INC_TYPE enumInc);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsI2CMasterCurrentWrite)(BYTE ucSlave, WORD usLength, const LPBYTE pucBuf);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsI2CMasterCurrentWriteEx)(BYTE ucSlave, WORD usLength, const LPBYTE pucBuf);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsI2CMasterWrite)(BYTE ucSlave, BYTE ucSub, WORD usLength, const LPBYTE pucBuf);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsI2CMasterWriteByte)(BYTE ucSlave, BYTE ucSub, BYTE ucValue);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsI2CMasterWriteEx)(BYTE ucSlave, BYTE ucSub, WORD usLength, const LPBYTE pucBuf, STRUCT_ENUM_INC_TYPE enumInc);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsI2CMasterWordWrite)(BYTE ucSlave, WORD usSub, WORD usLength, const LPBYTE pucBuf);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsI2CMasterWordWriteEx)(BYTE ucSlave, WORD usSub, WORD usLength, const LPBYTE pucBuf, STRUCT_ENUM_INC_TYPE enumInc);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsGetUsbDevicePath)(BYTE ucIndex, TCHAR* pcszDevicePath);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsSelectUsbByDevicePath)(TCHAR* pcszDevicePath);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsSelectUsbByIndex)(BYTE ucIndex);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsWriteFlashData)(DWORD ulFlashAddr, WORD usLen, LPBYTE pucBuf);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsReadFlashData)(DWORD ulFlashAddr, WORD usLen, LPBYTE pucBuf);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsSectorErase)(BYTE ucBankId, BYTE ucSectorId);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsBankErase)(BYTE ucBankId);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsDebugMessageEventStart)(WORD usFilterPro, LPBYTE pucBuf);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsDebugMessageEventFinish)(LPBYTE pucBuf);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsDebugMessageStart)(LPBYTE pucBuf);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsDebugMessageEnd)(LPBYTE pucBuf);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsDebugMessageGetValue)(LPBYTE pucBuf);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsDebugMessageGetString)(WORD usLen, LPBYTE pucBuf);
typedef void(*func_rsSetCmdLine)(TCHAR *pcCmd);
typedef STRUCT_ENUM_SPECIAL_COMM_TYPE(*func_rsGetSpecialCommType)();
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsSetSpecialCommType)(STRUCT_ENUM_SPECIAL_COMM_TYPE enumSpecialCommType);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsRead32BitRegEx)(DWORD ulReg, DWORD* pulValue);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsWrite32BitRegEx)(DWORD ulReg, DWORD ulValue);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsRead32BitRegsEx)(DWORD ulReg, WORD usLength, LPDWORD pulBuf, STRUCT_ENUM_INC_TYPE enumInc);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsWrite32BitRegsEx)(DWORD ulReg, WORD usLength, LPDWORD pulBuf, STRUCT_ENUM_INC_TYPE enumInc);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsReadDDRRegEx)(DWORD ulReg, DWORD* pulValue);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsWriteDDRRegEx)(DWORD ulReg, DWORD ulValue);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsReadDDRRegsEx)(DWORD ulReg, WORD usLength, LPDWORD pulBuf, STRUCT_ENUM_INC_TYPE enumInc);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsWriteDDRRegsEx)(DWORD ulReg, WORD usLength, LPDWORD pulBuf, STRUCT_ENUM_INC_TYPE enumInc);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsReadPWM2SPIReg)(BYTE ucDevIndex, BYTE ucRegStartAddr, BYTE ucLength, BYTE *pucBuf);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsWritePWM2SPIReg)(BYTE ucDevIndex, BYTE ucRegStartAddr, BYTE ucLength, BYTE *pucBuf);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsReadPWM2SPIDev)(BYTE ucDevIndex, BYTE ucPwmStartIndex, BYTE ucPwmNum, WORD *pusBuf);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsWritePWM2SPIDev)(BYTE ucDevIndex, BYTE ucPwmStartIndex, BYTE ucPwmNum, WORD *pusBuf);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsI2CWriteSegment)(BYTE ucSegSlave, BYTE ucSegAddr, BYTE ucSlave, BYTE ucSub, WORD usLength, const LPBYTE pucBuf);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsI2CWriteSegmentEx)(BYTE ucSegSlave, BYTE ucSegAddr, BYTE ucSlave, BYTE ucSub, WORD usLength, const LPBYTE pucBuf, STRUCT_ENUM_INC_TYPE enumInc);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsI2CReadSegment)(BYTE ucSegSlave, BYTE ucSegAddr, BYTE ucSlave, BYTE ucSub, WORD usLength, const LPBYTE pucBuf);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsI2CReadSegmentEx)(BYTE ucSegSlave, BYTE ucSegAddr, BYTE ucSlave, BYTE ucSub, WORD usLength, const LPBYTE pucBuf, STRUCT_ENUM_INC_TYPE enumInc);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsAutoEnterIspMode)(WORD usRetryTimes);
typedef STRUCT_ENUM_ERROR_TYPE(*func_rsSetSpecialCommType)(STRUCT_ENUM_SPECIAL_COMM_TYPE enumSpecialCommType);
typedef STRUCT_ENUM_SPECIAL_COMM_TYPE(*func_rsGetSpecialCommType)();

class CCpRsComm
{
public:
    CCpRsComm();
    ~CCpRsComm();

public:
    BOOL LoadCommDllFile(TCHAR* pcFile);
    void FreeCommDllFile();

    STRUCT_ENUM_ERROR_TYPE Initiallize();
    // Get current device count, this function must be called after rsInitiallize has been called
    WORD GetCommCount();
    STRUCT_ENUM_COMM_ID GetCommID();
    void GetCommName(TCHAR* szName, WORD usLength);
    //void GetAllCommName(TCHAR pcNames[][256]);
    STRUCT_ENUM_ERROR_TYPE GetCommFile(STRUCT_COMM_INFO *pstCommVer);
    STRUCT_ENUM_ERROR_TYPE SetCommByIndex(WORD usCommIndex);
    STRUCT_ENUM_ERROR_TYPE SetCommByID(STRUCT_ENUM_COMM_ID enumCommID);
    STRUCT_ENUM_ERROR_TYPE SetDebugSlave(BYTE ucDebugSlave);
    STRUCT_ENUM_ERROR_TYPE SetIspSlave(BYTE ucIspSlave);
    STRUCT_ENUM_ERROR_TYPE SetIspContinuousSlave(BYTE ucIspContinuousSlave);
    BYTE GetDebugSlave();
    BYTE GetIspSlave();
    BYTE GetIspContinuousSlave();
    STRUCT_ENUM_ERROR_TYPE SetDebugMode(STRUCT_ENUM_DEBUG_TYPE enumDebugType);
    STRUCT_ENUM_DEBUG_TYPE GetDebugMode();

    WORD GetI2CPageLength();
    WORD GetNativePageLength();
    STRUCT_ENUM_ERROR_TYPE I2CWrite(BYTE ucSlave, BYTE ucSub, WORD usLength, const LPBYTE pucBuf);
    STRUCT_ENUM_ERROR_TYPE I2CRead(BYTE ucSlave, BYTE ucSub, WORD usLength, LPBYTE pucBuf);
    STRUCT_ENUM_ERROR_TYPE I2CWriteByte(BYTE ucSlave, BYTE ucSub, BYTE ucValue);
    STRUCT_ENUM_ERROR_TYPE I2CCurrentRead(BYTE ucSlave, WORD usLength, LPBYTE pucBuf);
    STRUCT_ENUM_ERROR_TYPE I2CWordWrite(BYTE ucSlave, WORD usSub, WORD usLength, const LPBYTE pucBuf);
    STRUCT_ENUM_ERROR_TYPE I2CWordRead(BYTE ucSlave, WORD usSub, WORD usLength, LPBYTE pucBuf);
    STRUCT_ENUM_ERROR_TYPE I2CWriteEx(BYTE ucSlave, BYTE ucSub, WORD usLength, const LPBYTE pucBuf, STRUCT_ENUM_INC_TYPE enumInc);
    STRUCT_ENUM_ERROR_TYPE I2CReadEx(BYTE ucSlave, BYTE ucSub, WORD usLength, LPBYTE pucBuf, STRUCT_ENUM_INC_TYPE enumInc);
    STRUCT_ENUM_ERROR_TYPE I2CCurrentReadEx(BYTE ucSlave, WORD usLength, LPBYTE pucBuf);
    STRUCT_ENUM_ERROR_TYPE I2CWordWriteEx(BYTE ucSlave, WORD usSub, WORD usLength, const LPBYTE pucBuf, STRUCT_ENUM_INC_TYPE enumInc = _INCTYPE_AUTO);
    STRUCT_ENUM_ERROR_TYPE I2CWordReadEx(BYTE ucSlave, WORD usSub, WORD usLength, LPBYTE pucBuf, STRUCT_ENUM_INC_TYPE enumInc = _INCTYPE_AUTO);
    STRUCT_ENUM_ERROR_TYPE AdjustOption();
    STRUCT_ENUM_ERROR_TYPE SetI2CSpeed(WORD usSpeed);
    WORD GetI2CSpeed();
    STRUCT_ENUM_ERROR_TYPE SetAuxMode(STRUCT_AUXMODE_STRUCT stAuxMode);
    STRUCT_ENUM_ERROR_TYPE SetWaitingMode(STRUCT_WAITING_STRUCT stWaiting);
    STRUCT_WAITING_STRUCT GetWaitingMode();

    virtual STRUCT_ENUM_ERROR_TYPE ReadReg(BYTE ucReg, BYTE* pucValue);
    virtual STRUCT_ENUM_ERROR_TYPE WriteReg(BYTE ucReg, BYTE ucValue);
    STRUCT_ENUM_ERROR_TYPE ReadRegs(BYTE ucReg, WORD usLength, LPBYTE pucBuf, STRUCT_ENUM_INC_TYPE enumInc);
    STRUCT_ENUM_ERROR_TYPE WriteRegs(BYTE ucReg, WORD usLength, LPBYTE pucBuf, STRUCT_ENUM_INC_TYPE enumInc);
    STRUCT_ENUM_ERROR_TYPE WriteRegBit(BYTE ucReg, BYTE ucAnd, BYTE ucOr);
    STRUCT_ENUM_ERROR_TYPE WritePortRegBit(BYTE ucAddrReg, BYTE ucDataReg, BYTE ucAnd, BYTE ucOr);
    virtual STRUCT_ENUM_ERROR_TYPE ReadRegEx(WORD usReg, BYTE* pucValue);
    virtual STRUCT_ENUM_ERROR_TYPE WriteRegEx(WORD usReg, BYTE ucValue);
    STRUCT_ENUM_ERROR_TYPE ReadRegsEx(WORD usReg, WORD usLength, LPBYTE pucBuf, STRUCT_ENUM_INC_TYPE enumInc);
    STRUCT_ENUM_ERROR_TYPE WriteRegsEx(WORD usReg, WORD usLength, LPBYTE pucBuf, STRUCT_ENUM_INC_TYPE enumInc);
    STRUCT_ENUM_ERROR_TYPE WriteRegBitEx(WORD usReg, BYTE ucAnd, BYTE ucOr);
    STRUCT_ENUM_ERROR_TYPE WritePortRegBitEx(WORD usAddrReg, WORD usDataReg, BYTE ucAnd, BYTE ucOr);
    STRUCT_ENUM_ERROR_TYPE ReadSysDevice(BYTE ucSlave, BYTE ucSub, BYTE ucLength, LPBYTE pucBuf, STRUCT_ENUM_SYS_DEVICE_CMD_TYPE enumCmdType = _SYS_DEVICE_CMD_DEFAULT);
    STRUCT_ENUM_ERROR_TYPE WriteSysDevice(BYTE ucSlave, BYTE ucSub, BYTE ucLength, LPBYTE pucBuf, STRUCT_ENUM_SYS_DEVICE_CMD_TYPE enumCmdType = _SYS_DEVICE_CMD_DEFAULT);
    STRUCT_ENUM_ERROR_TYPE ReadWordSysDevice(BYTE ucSlave, WORD usSub, BYTE ucLength, LPBYTE pucBuf, STRUCT_ENUM_SYS_DEVICE_CMD_TYPE enumCmdType = _SYS_DEVICE_CMD_DEFAULT);
    STRUCT_ENUM_ERROR_TYPE WriteWordSysDevice(BYTE ucSlave, WORD usSub, BYTE ucLength, LPBYTE pucBuf, STRUCT_ENUM_SYS_DEVICE_CMD_TYPE enumCmdType = _SYS_DEVICE_CMD_DEFAULT);
    virtual STRUCT_ENUM_ERROR_TYPE ScalerStop();
    virtual STRUCT_ENUM_ERROR_TYPE ScalerRun();

    STRUCT_ENUM_ERROR_TYPE WriteMcuReg(WORD usReg, BYTE ucValue);
    STRUCT_ENUM_ERROR_TYPE WriteMcuRegBit(WORD usReg, BYTE ucAnd, BYTE ucOr);
    STRUCT_ENUM_ERROR_TYPE ReadMcuReg(WORD usReg, BYTE* pucValue);
    STRUCT_ENUM_ERROR_TYPE WriteMcuRegs(WORD usReg, WORD usLength, LPBYTE pucBuf, STRUCT_ENUM_INC_TYPE enumInc = _INCTYPE_AUTO);
    STRUCT_ENUM_ERROR_TYPE ReadMcuRegs(WORD usReg, WORD usLength, LPBYTE pucBuf, STRUCT_ENUM_INC_TYPE enumInc = _INCTYPE_AUTO);
    STRUCT_ENUM_ERROR_TYPE WriteContinuousMcuReg(BYTE ucSub, WORD usLength, LPBYTE pucBuf, STRUCT_ENUM_INC_TYPE enumInc = _INCTYPE_AUTO);
    STRUCT_ENUM_ERROR_TYPE ReadContinuousMcuReg(BYTE ucSub, WORD usLength, LPBYTE pucBuf, STRUCT_ENUM_INC_TYPE enumInc = _INCTYPE_AUTO);
    STRUCT_ENUM_ERROR_TYPE ReleaseDev();
    STRUCT_ENUM_ERROR_TYPE NativeWrite(INT nAddress, WORD usLength, const LPBYTE pucBuf);
    STRUCT_ENUM_ERROR_TYPE NativeRead(INT nAddress, WORD usLength, LPBYTE pucBuf);
    void SetSettingFilePath(TCHAR *pcConfigFilePath);
    void * GetDeviceHandler();
    STRUCT_ENUM_ERROR_TYPE ResetFirmware();
    virtual STRUCT_ENUM_ERROR_TYPE EnterIspMode(WORD usRetryTimes);
    DWORD GetSMBUSDataType();
    STRUCT_ENUM_ERROR_TYPE SetSMBUSDataType(DWORD ulSMBUSDataType);
    BYTE GetDeviceCount();
    STRUCT_ENUM_ERROR_TYPE RemoveDevice();
    virtual STRUCT_ENUM_ERROR_TYPE AutoDetectSlaveAddr();
    virtual STRUCT_ENUM_ERROR_TYPE DDCCIWrite(BYTE ucSlave, BYTE ucSub, BYTE ucLength, const LPBYTE pucBuf);
    STRUCT_ENUM_ERROR_TYPE DDCCIRead(BYTE ucSlave, BYTE ucSub, BYTE ucLength, LPBYTE pucBuf);
    STRUCT_ENUM_ERROR_TYPE SetFTDIGetAck(BOOL bEnable);
    BOOL GetFTDIGetAckStatus();
    STRUCT_ENUM_ERROR_TYPE GetUsbDevicePath(BYTE ucIndex, TCHAR* pcszDevicePath);
    STRUCT_ENUM_ERROR_TYPE SelectUsbByDevicePath(TCHAR* pcszDevicePath);
    STRUCT_ENUM_ERROR_TYPE SelectUsbByIndex(BYTE ucIndex);

    STRUCT_ENUM_ERROR_TYPE I2CMasterInitial(STRUCT_ENUM_IIC_MASTER_SPEED enumI2cMasterSpeed);
    STRUCT_ENUM_ERROR_TYPE I2CMasterCurrentRead(BYTE ucSlave, WORD usLength, LPBYTE pucBuf);
    STRUCT_ENUM_ERROR_TYPE I2CMasterCurrentReadEx(BYTE ucSlave, WORD usLength, LPBYTE pucBuf);
    STRUCT_ENUM_ERROR_TYPE I2CMasterRead(BYTE ucSlave, BYTE ucSub, WORD usLength, LPBYTE pucBuf);
    STRUCT_ENUM_ERROR_TYPE I2CMasterReadEx(BYTE ucSlave, BYTE ucSub, WORD usLength, LPBYTE pucBuf, STRUCT_ENUM_INC_TYPE enumInc = _INCTYPE_AUTO);
    STRUCT_ENUM_ERROR_TYPE I2CMasterWordRead(BYTE ucSlave, WORD usSub, WORD usLength, LPBYTE pucBuf);
    STRUCT_ENUM_ERROR_TYPE I2CMasterWordReadEx(BYTE ucSlave, WORD usSub, WORD usLength, LPBYTE pucBuf, STRUCT_ENUM_INC_TYPE enumInc = _INCTYPE_AUTO);
    STRUCT_ENUM_ERROR_TYPE I2CMasterCurrentWrite(BYTE ucSlave, WORD usLength, const LPBYTE pucBuf);
    STRUCT_ENUM_ERROR_TYPE I2CMasterCurrentWriteEx(BYTE ucSlave, WORD usLength, const LPBYTE pucBuf);
    STRUCT_ENUM_ERROR_TYPE I2CMasterWrite(BYTE ucSlave, BYTE ucSub, WORD usLength, const LPBYTE pucBuf);
    STRUCT_ENUM_ERROR_TYPE I2CMasterWriteByte(BYTE ucSlave, BYTE ucSub, BYTE ucValue);
    STRUCT_ENUM_ERROR_TYPE I2CMasterWriteEx(BYTE ucSlave, BYTE ucSub, WORD usLength, const LPBYTE pucBuf, STRUCT_ENUM_INC_TYPE enumInc = _INCTYPE_AUTO);
    STRUCT_ENUM_ERROR_TYPE I2CMasterWordWrite(BYTE ucSlave, WORD usSub, WORD usLength, const LPBYTE pucBuf);
    STRUCT_ENUM_ERROR_TYPE I2CMasterWordWriteEx(BYTE ucSlave, WORD usSub, WORD usLength, const LPBYTE pucBuf, STRUCT_ENUM_INC_TYPE enumInc = _INCTYPE_AUTO);
    STRUCT_ENUM_ERROR_TYPE WriteFlashData(DWORD ulFlashAddr, WORD usLen, LPBYTE pucBuf);
    STRUCT_ENUM_ERROR_TYPE ReadFlashData(DWORD ulFlashAddr, WORD usLen, LPBYTE pucBuf);
    //     STRUCT_ENUM_ERROR_TYPE SectorErase(BYTE ucBankId, BYTE ucSectorId);
    //     STRUCT_ENUM_ERROR_TYPE BankErase(BYTE ucBankId);
    void SetCmdLine(TCHAR *pcCmd);
    STRUCT_ENUM_SPECIAL_COMM_TYPE GetSpecialCommType();
    STRUCT_ENUM_ERROR_TYPE SetSpecialCommType(STRUCT_ENUM_SPECIAL_COMM_TYPE enumSpecialCommType);
    STRUCT_ENUM_ERROR_TYPE Read32BitRegEx(DWORD ulReg, DWORD* pulValue);
    STRUCT_ENUM_ERROR_TYPE Write32BitRegEx(DWORD ulReg, DWORD ulValue);
    STRUCT_ENUM_ERROR_TYPE Read32BitRegsEx(DWORD ulReg, WORD usLength, LPDWORD pulBuf, STRUCT_ENUM_INC_TYPE enumInc);
    STRUCT_ENUM_ERROR_TYPE Write32BitRegsEx(DWORD ulReg, WORD usLength, LPDWORD pulBuf, STRUCT_ENUM_INC_TYPE enumInc);
    STRUCT_ENUM_ERROR_TYPE ReadDDRRegEx(DWORD ulReg, DWORD* pulValue);
    STRUCT_ENUM_ERROR_TYPE WriteDDRRegEx(DWORD ulReg, DWORD ulValue);
    STRUCT_ENUM_ERROR_TYPE ReadDDRRegsEx(DWORD ulReg, WORD usLength, LPDWORD pulBuf, STRUCT_ENUM_INC_TYPE enumInc);
    STRUCT_ENUM_ERROR_TYPE WriteDDRRegsEx(DWORD ulReg, WORD usLength, LPDWORD pulBuf, STRUCT_ENUM_INC_TYPE enumInc);
    STRUCT_ENUM_ERROR_TYPE ReadPWM2SPIReg(BYTE ucDevIndex, BYTE ucRegStartAddr, BYTE ucLength, BYTE *pucBuf);
    STRUCT_ENUM_ERROR_TYPE WritePWM2SPIReg(BYTE ucDevIndex, BYTE ucRegStartAddr, BYTE ucLength, BYTE *pucBuf);
    STRUCT_ENUM_ERROR_TYPE ReadPWM2SPIDev(BYTE ucDevIndex, BYTE ucPwmStartIndex, BYTE ucPwmNum, WORD *pusBuf);
    STRUCT_ENUM_ERROR_TYPE WritePWM2SPIDev(BYTE ucDevIndex, BYTE ucPwmStartIndex, BYTE ucPwmNum, WORD *pusBuf);
    STRUCT_ENUM_ERROR_TYPE I2CWriteSegment(BYTE ucSegSlave, BYTE ucSegAddr, BYTE ucSlave, BYTE ucSub, WORD usLength, const LPBYTE pucBuf);
    STRUCT_ENUM_ERROR_TYPE I2CWriteSegmentEx(BYTE ucSegSlave, BYTE ucSegAddr, BYTE ucSlave, BYTE ucSub, WORD usLength, const LPBYTE pucBuf, STRUCT_ENUM_INC_TYPE enumInc);
    STRUCT_ENUM_ERROR_TYPE I2CReadSegment(BYTE ucSegSlave, BYTE ucSegAddr, BYTE ucSlave, BYTE ucSub, WORD usLength, const LPBYTE pucBuf);
    STRUCT_ENUM_ERROR_TYPE I2CReadSegmentEx(BYTE ucSegSlave, BYTE ucSegAddr, BYTE ucSlave, BYTE ucSub, WORD usLength, const LPBYTE pucBuf, STRUCT_ENUM_INC_TYPE enumInc);
    STRUCT_ENUM_ERROR_TYPE DebugMessageEventStart(WORD usFilterPro, LPBYTE pucBuf);
    STRUCT_ENUM_ERROR_TYPE DebugMessageEventFinish(LPBYTE pucBuf);
    STRUCT_ENUM_ERROR_TYPE DebugMessageStart(LPBYTE pucBuf);
    STRUCT_ENUM_ERROR_TYPE DebugMessageEnd(LPBYTE pucBuf);
    STRUCT_ENUM_ERROR_TYPE DebugMessageGetValue(LPBYTE pucBuf);
    STRUCT_ENUM_ERROR_TYPE DebugMessageGetString(WORD usLen, LPBYTE pucBuf);
    STRUCT_ENUM_ERROR_TYPE AutoEnterIspMode(WORD usRetryTimes);

private:
    void* m_hCommDll;

    func_rsGetI2CPageLength m_rsGetI2CPageLength;
    func_rsI2CWrite m_rsI2CWrite;
    func_rsI2CRead m_rsI2CRead;
    func_rsInitiallize m_rsInitiallize;
    func_rsGetCommCount m_rsGetCommCount;
    func_rsGetCommID m_rsGetCommID;
    func_rsGetCommName m_rsGetCommName;
    func_rsGetCommFile m_rsGetCommFile;
    func_rsSetCommByIndex m_rsSetCommByIndex;
    func_rsSetCommByID m_rsSetCommByID;
    func_rsSetDebugSlave m_rsSetDebugSlave;
    func_rsSetIspSlave m_rsSetIspSlave;
    func_rsSetIspContinuousSlave m_rsSetIspContinuousSlave;
    func_rsGetDebugSlave m_rsGetDebugSlave;
    func_rsGetIspSlave m_rsGetIspSlave;
    func_rsGetIspContinuousSlave m_rsGetIspContinuousSlave;
    func_rsSetDebugMode m_rsSetDebugMode;
    func_rsGetDebugMode m_rsGetDebugMode;

    func_rsGetNativePageLength m_rsGetNativePageLength;
    func_rsI2CWriteByte m_rsI2CWriteByte;
    func_rsI2CCurrentRead m_rsI2CCurrentRead;
    func_rsI2CWordWrite m_rsI2CWordWrite;
    func_rsI2C2SubWrite m_rsI2C2SubWrite;
    func_rsI2CWordRead m_rsI2CWordRead;
    func_rsI2C2SubRead m_rsI2C2SubRead;
    func_rsI2CWriteEx m_rsI2CWriteEx;
    func_rsI2CReadEx m_rsI2CReadEx;
    func_rsI2CCurrentReadEx m_rsI2CCurrentReadEx;
    func_rsI2CWordWriteEx m_rsI2CWordWriteEx;
    func_rsI2C2SubWriteEx m_rsI2C2SubWriteEx;
    func_rsI2CWordReadEx m_rsI2CWordReadEx;
    func_rsI2C2SubReadEx m_rsI2C2SubReadEx;
    func_rsAdjustOption m_rsAdjustOption;
    func_rsSetI2CSpeed m_rsSetI2CSpeed;
    func_rsGetI2CSpeed m_rsGetI2CSpeed;
    func_rsSetAuxMode m_rsSetAuxMode;
    func_rsSetWaitingMode m_rsSetWaitingMode;
    func_rsGetWaitingMode m_rsGetWaitingMode;
    func_rsReadReg m_rsReadReg;
    func_rsWriteReg m_rsWriteReg;
    func_rsReadRegs m_rsReadRegs;
    func_rsWriteRegs m_rsWriteRegs;
    func_rsWriteRegBit m_rsWriteRegBit;
    func_rsWritePortRegBit m_rsWritePortRegBit;
    func_rsReadRegEx m_rsReadRegEx;
    func_rsWriteRegEx m_rsWriteRegEx;
    func_rsReadRegsEx m_rsReadRegsEx;
    func_rsWriteRegsEx m_rsWriteRegsEx;
    func_rsWriteRegBitEx m_rsWriteRegBitEx;
    func_rsWritePortRegBitEx m_rsWritePortRegBitEx;
    func_rsReadSysDevice m_rsReadSysDevice;
    func_rsWriteSysDevice m_rsWriteSysDevice;
    func_rsReadWordSysDevice m_rsReadWordSysDevice;
    func_rsWriteWordSysDevice m_rsWriteWordSysDevice;
    func_rsScalerStop m_rsScalerStop;
    func_rsScalerRun m_rsScalerRun;
    func_rsWriteMcuReg m_rsWriteMcuReg;
    func_rsWriteMcuRegs m_rsWriteMcuRegs;
    func_rsReadMcuReg m_rsReadMcuReg;
    func_rsWriteMcuRegBit m_rsWriteMcuRegBit;
    func_rsReadMcuRegs m_rsReadMcuRegs;
    func_rsWriteContinuousMcuReg m_rsWriteContinuousMcuReg;
    func_rsReadContinuousMcuReg m_rsReadContinuousMcuReg;
    func_rsReleaseDev m_rsReleaseDev;
    func_rsNativeWrite m_rsNativeWrite;
    func_rsNativeRead m_rsNativeRead;
    func_rsSetConfigFilePath m_rsSetConfigFilePath;
    func_rsGetDeviceHandler m_rsGetDeviceHandler;
    func_rsResetFirmware m_rsResetFirmware;
    func_rsEnterIspMode m_rsEnterIspMode;
    func_rsGetSMBUSDataType m_rsGetSMBUSDataType;
    func_rsSetSMBUSDataType m_rsSetSMBUSDataType;
    func_rsGetDeviceCount m_rsGetDeviceCount;
    func_rsRemoveDevice m_rsRemoveDevice;
    func_rsAutoDetectSlaveAddr m_rsAutoDetectSlaveAddr;
    func_rsDDCCIWrite m_rsDDCCIWrite;
    func_rsDDCCIRead m_rsDDCCIRead;
    func_rsSetFTDIGetAck m_rsSetFTDIGetAck;
    func_rsGetFTDIGetAckStatus m_rsGetFTDIGetAckStatus;

    func_rsI2CMasterInitial m_rsI2CMasterInitial;
    func_rsI2CMasterCurrentRead m_rsI2CMasterCurrentRead;
    func_rsI2CMasterCurrentReadEx m_rsI2CMasterCurrentReadEx;
    func_rsI2CMasterRead m_rsI2CMasterRead;
    func_rsI2CMasterReadEx m_rsI2CMasterReadEx;
    func_rsI2CMasterWordRead m_rsI2CMasterWordRead;
    func_rsI2CMasterWordReadEx m_rsI2CMasterWordReadEx;
    func_rsI2CMasterCurrentWrite m_rsI2CMasterCurrentWrite;
    func_rsI2CMasterCurrentWriteEx m_rsI2CMasterCurrentWriteEx;
    func_rsI2CMasterWrite m_rsI2CMasterWrite;
    func_rsI2CMasterWriteByte m_rsI2CMasterWriteByte;
    func_rsI2CMasterWriteEx m_rsI2CMasterWriteEx;
    func_rsI2CMasterWordWrite m_rsI2CMasterWordWrite;
    func_rsI2CMasterWordWriteEx m_rsI2CMasterWordWriteEx;

    func_rsGetUsbDevicePath m_rsGetUsbDevicePath;
    func_rsSelectUsbByDevicePath m_rsSelectUsbByDevicePath;
    func_rsSelectUsbByIndex m_rsSelectUsbByIndex;
    func_rsWriteFlashData m_rsWriteFlashData;
    func_rsReadFlashData m_rsReadFlashData;
    func_rsSectorErase m_rsSectorErase;
    func_rsBankErase m_rsBankErase;
    func_rsDebugMessageEventStart m_rsDebugMessageEventStart;
    func_rsDebugMessageEventFinish m_rsDebugMessageEventFinish;
    func_rsDebugMessageStart m_rsDebugMessageStart;
    func_rsDebugMessageEnd m_rsDebugMessageEnd;
    func_rsDebugMessageGetValue m_rsDebugMessageGetValue;
    func_rsDebugMessageGetString m_rsDebugMessageGetString;
    func_rsSetCmdLine m_rsSetCmdLine;
    func_rsGetSpecialCommType m_rsGetSpecialCommType;
    func_rsSetSpecialCommType m_rsSetSpecialCommType;
    func_rsRead32BitRegEx m_rsRead32BitRegEx;
    func_rsWrite32BitRegEx m_rsWrite32BitRegEx;
    func_rsRead32BitRegsEx m_rsRead32BitRegsEx;
    func_rsWrite32BitRegsEx m_rsWrite32BitRegsEx;
    func_rsReadDDRRegEx m_rsReadDDRRegEx;
    func_rsWriteDDRRegEx m_rsWriteDDRRegEx;
    func_rsReadDDRRegsEx m_rsReadDDRRegsEx;
    func_rsWriteDDRRegsEx m_rsWriteDDRRegsEx;
    func_rsReadPWM2SPIReg m_rsReadPWM2SPIReg;
    func_rsWritePWM2SPIReg m_rsWritePWM2SPIReg;
    func_rsReadPWM2SPIDev m_rsReadPWM2SPIDev;
    func_rsWritePWM2SPIDev m_rsWritePWM2SPIDev;
    func_rsI2CWriteSegment m_rsI2CWriteSegment;
    func_rsI2CWriteSegmentEx m_rsI2CWriteSegmentEx;
    func_rsI2CReadSegment m_rsI2CReadSegment;
    func_rsI2CReadSegmentEx m_rsI2CReadSegmentEx;
    func_rsAutoEnterIspMode m_rsAutoEnterIspMode;

    //////////////////////////////////////////////////////////////////////////
};

#endif // End of #ifndef _COMM_EXPORT_H_
