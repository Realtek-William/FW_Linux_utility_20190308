#include "UnixParseArgs.h"
#include <getopt.h>
#include <string>

using namespace std;

CUnixParseArgs::CUnixParseArgs()
{
}


CUnixParseArgs::~CUnixParseArgs()
{
}

int CUnixParseArgs::ParseArgs(int argc, char *const *argv)
{
    STRUCT_COMMAND_ARGS_SETTING stArgSetting;
    INT nFuncTemp = 0, nVerTemp = 0;

    struct option longopts[] ={
        {"comm", required_argument, NULL, COMMAND_CP_ISPTOOL_COMMUNICATION},
        {"erase", no_argument, &nFuncTemp, CP_ISPTOOL_FUNC_ERASE},
        {"isp", no_argument, &nFuncTemp, CP_ISPTOOL_FUNC_ISP_NORMAL},
        {"isphw", no_argument, &nFuncTemp, CP_ISPTOOL_FUNC_ISP_NORMAL_HW_SIGN},
        {"ispsw", no_argument, &nFuncTemp, CP_ISPTOOL_FUNC_ISP_NORMAL_SW_SIGN},
        {"ispuser", no_argument, &nFuncTemp, CP_ISPTOOL_FUNC_ISP_FW_PARTITION},
        {"ispuserhw", no_argument, &nFuncTemp, CP_ISPTOOL_FUNC_ISP_FW_PARTITION_HW_SIGN},
        {"ispusersw", no_argument, &nFuncTemp, CP_ISPTOOL_FUNC_ISP_FW_PARTITION_SW_SIGN},
        {"ispdiff", no_argument, &nFuncTemp, CP_ISPTOOL_FUNC_ISP_DIFFER_BANK},
        {"ispiffhw", no_argument, &nFuncTemp, CP_ISPTOOL_FUNC_ISP_DIFFER_BANK_HW_SIGN},
        {"ispiffsw", no_argument, &nFuncTemp, CP_ISPTOOL_FUNC_ISP_DIFFER_BANK_SW_SIGN},
        {"ispcopy", no_argument, &nFuncTemp, CP_ISPTOOL_FUNC_ISP_COPY_BANK},
        {"ispcopyhw", no_argument, &nFuncTemp, CP_ISPTOOL_FUNC_ISP_COPY_BANK_HW_SIGN},
        {"ispcopysw", no_argument, &nFuncTemp, CP_ISPTOOL_FUNC_ISP_COPY_BANK_SW_SIGN},
        {"fw", required_argument, NULL, COMMAND_CP_DIGITAL_SIGN_FW},
        {"sig", required_argument, NULL, COMMAND_CP_DIGITAL_SIGN_SIGNATURE},
        {"pair", required_argument, NULL, COMMAND_CP_DIGITAL_SIGN_RTK_KEY_PAIR},
        {"pubkey", required_argument, NULL, COMMAND_CP_DIGITAL_SIGN_PUBLIC_KEY},
        {"subcert", required_argument, NULL, COMMAND_CP_DIGITAL_SIGN_SUB_CERT},
        {"bank", required_argument, NULL, COMMAND_CP_ISPTOOL_START_BANK},
        {"fw1", required_argument, NULL, COMMAND_CP_ISPTOOL_FW_1},
        {"bank1", required_argument, NULL, COMMAND_CP_ISPTOOL_START_BANK_1},
        {"fw2", required_argument, NULL, COMMAND_CP_ISPTOOL_FW_2},
        {"bank2", required_argument, NULL, COMMAND_CP_ISPTOOL_START_BANK_2},
        {"fw3", required_argument, NULL, COMMAND_CP_ISPTOOL_FW_3},
        {"bank3", required_argument, NULL, COMMAND_CP_ISPTOOL_START_BANK_3},
        {"fw4", required_argument, NULL, COMMAND_CP_ISPTOOL_FW_4},
        {"bank4", required_argument, NULL, COMMAND_CP_ISPTOOL_START_BANK_4},
        {"fw5", required_argument, NULL, COMMAND_CP_ISPTOOL_FW_5},
        {"bank5", required_argument, NULL, COMMAND_CP_ISPTOOL_START_BANK_5},
        {"fw6", required_argument, NULL, COMMAND_CP_ISPTOOL_FW_6},
        {"bank6", required_argument, NULL, COMMAND_CP_ISPTOOL_START_BANK_6},
        {"fw7", required_argument, NULL, COMMAND_CP_ISPTOOL_FW_7},
        {"bank7", required_argument, NULL, COMMAND_CP_ISPTOOL_START_BANK_7},
        {"fw8", required_argument, NULL, COMMAND_CP_ISPTOOL_FW_8},
        {"bank8", required_argument, NULL, COMMAND_CP_ISPTOOL_START_BANK_8},
        {"fw9", required_argument, NULL, COMMAND_CP_ISPTOOL_FW_9},
        {"bank9", required_argument, NULL, COMMAND_CP_ISPTOOL_START_BANK_9},

        {"ver", no_argument, NULL, COMMAND_CP_ISPTOOL_READ_VERSION},
        {"reg", no_argument, &nVerTemp, CP_ISPTOOL_VER_FROM_REG},
        {"ddcci", no_argument, &nVerTemp, CP_ISPTOOL_VER_FROM_DDCCI},
        {"flash", no_argument, &nVerTemp, CP_ISPTOOL_VER_FROM_FLASH},

        {"flagaddr", required_argument, NULL, COMMAND_CP_ISPTOOL_USER_FLAG_ADDR},

        {"slave", required_argument, NULL, COMMAND_CP_ISPTOOL_ISP_SLAVE_ADDR},
        {0, 0, 0, 0},
    };

    int nRet = 0;
    while((nRet = getopt_long(argc, argv, "", longopts, NULL)) != -1)
    {
        switch(nRet)
        {
        case 0:
            stArgSetting.nFunc |= nFuncTemp;
            stArgSetting.nVerType |= nVerTemp;
            break;
        case COMMAND_CP_DIGITAL_SIGN_FW:
            if(!InsertCommandFwFile(0, optarg))
            {
                return false;
            }
            break;
        case COMMAND_CP_ISPTOOL_START_BANK:
            if(!InsertCommandStartBank(0, optarg))
            {
                return false;
            }
            break;
        case COMMAND_CP_DIGITAL_SIGN_SIGNATURE:
            m_stCmd.strSig = optarg;
            break;
        case COMMAND_CP_DIGITAL_SIGN_RTK_KEY_PAIR:
            m_stCmd.strKeyPair = optarg;
            break;
        case COMMAND_CP_DIGITAL_SIGN_PUBLIC_KEY:
            m_stCmd.strPublic = optarg;
            break;
        case COMMAND_CP_DIGITAL_SIGN_SUB_CERT:
            m_stCmd.strSubCert = optarg;
            break;
        case COMMAND_CP_ISPTOOL_FW_1:
            if(!InsertCommandFwFile(1, optarg))
            {
                return false;
            }
            break;
        case COMMAND_CP_ISPTOOL_START_BANK_1:
            if(!InsertCommandStartBank(1, optarg))
            {
                return false;
            }
            break;
        case COMMAND_CP_ISPTOOL_FW_2:
            if(!InsertCommandFwFile(2, optarg))
            {
                return false;
            }
            break;
        case COMMAND_CP_ISPTOOL_START_BANK_2:
            if(!InsertCommandStartBank(2, optarg))
            {
                return false;
            }
            break;
        case COMMAND_CP_ISPTOOL_FW_3:
            if(!InsertCommandFwFile(3, optarg))
            {
                return false;
            }
            break;
        case COMMAND_CP_ISPTOOL_START_BANK_3:
            if(!InsertCommandStartBank(3, optarg))
            {
                return false;
            }
            break;
        case COMMAND_CP_ISPTOOL_FW_4:
            if(!InsertCommandFwFile(4, optarg))
            {
                return false;
            }
            break;
        case COMMAND_CP_ISPTOOL_START_BANK_4:
            if(!InsertCommandStartBank(4, optarg))
            {
                return false;
            }
            break;
        case COMMAND_CP_ISPTOOL_FW_5:
            if(!InsertCommandFwFile(5, optarg))
            {
                return false;
            }
            break;
        case COMMAND_CP_ISPTOOL_START_BANK_5:
            if(!InsertCommandStartBank(5, optarg))
            {
                return false;
            }
            break;
        case COMMAND_CP_ISPTOOL_FW_6:
            if(!InsertCommandFwFile(6, optarg))
            {
                return false;
            }
            break;
        case COMMAND_CP_ISPTOOL_START_BANK_6:
            if(!InsertCommandStartBank(6, optarg))
            {
                return false;
            }
            break;
        case COMMAND_CP_ISPTOOL_FW_7:
            if(!InsertCommandFwFile(7, optarg))
            {
                return false;
            }
            break;
        case COMMAND_CP_ISPTOOL_START_BANK_7:
            if(!InsertCommandStartBank(7, optarg))
            {
                return false;
            }
            break;
        case COMMAND_CP_ISPTOOL_FW_8:
            if(!InsertCommandFwFile(8, optarg))
            {
                return false;
            }
            break;
        case COMMAND_CP_ISPTOOL_START_BANK_8:
            if(!InsertCommandStartBank(8, optarg))
            {
                return false;
            }
            break;
        case COMMAND_CP_ISPTOOL_FW_9:
            if(!InsertCommandFwFile(9, optarg))
            {
                return false;
            }
            break;
        case COMMAND_CP_ISPTOOL_START_BANK_9:
            if(!InsertCommandStartBank(9, optarg))
            {
                return false;
            }
            break;
        case COMMAND_CP_ISPTOOL_ISP_SLAVE_ADDR:
            stArgSetting.strSlave = optarg;
            break;
        case COMMAND_CP_ISPTOOL_COMMUNICATION:
            stArgSetting.strCommID = optarg;
            break;
        case COMMAND_CP_ISPTOOL_READ_VERSION:
            stArgSetting.bReadVer = true;
            break;
        case COMMAND_CP_ISPTOOL_USER_FLAG_ADDR:
            stArgSetting.strUserFlagAddr = optarg;
            break;
        case '?':
            printf("illegal option \' %c \'!\n", (char)optopt);
            break;
        default:
            break;
        }
    }

    if(optind < argc)
    {
        printf("non-option ARGV-elements: ");
        while(optind < argc)
            printf("%s ", argv[optind++]);
        printf("\n");
    }

    return JudgeArgument(stArgSetting);
}

