#pragma once
#include "CpParseArgsBase.h"

class CUnixParseArgs :
    public CCpParseArgsBase
{
public:
    CUnixParseArgs();
    ~CUnixParseArgs();

    int ParseArgs(int argc, char *const *argv);
};

