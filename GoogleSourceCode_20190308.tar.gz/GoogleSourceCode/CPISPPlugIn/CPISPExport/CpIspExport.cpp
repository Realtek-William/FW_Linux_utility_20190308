#include "stdafx.h"
#include "CpIspExport.h"
#include "../../Tool_Common/RsCommon/ErrorDefine.h"

CCpIsp::CCpIsp()
{
    m_hHandle = NULL;
}


CCpIsp::~CCpIsp()
{
}

STRUCT_ENUM_ERROR_TYPE CCpIsp::IspFlash(STRUCT_CP_ISP_COMMAND_SETTING &stCmdSetting)
{
    if(m_rsIspFlash == NULL)
    {
        return _ERROR_COMM_NO_INITIAL;
    }
    return m_rsIspFlash(stCmdSetting);
}

void CCpIsp::SetCommInterface(CCpRsComm *pRsComm)
{
    if(m_rsSetCommInterface == NULL)
    {
        return;
    }
    return m_rsSetCommInterface(pRsComm);
}