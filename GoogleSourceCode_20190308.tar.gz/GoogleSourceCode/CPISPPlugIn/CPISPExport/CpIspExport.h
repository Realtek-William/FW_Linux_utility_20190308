#ifndef _ISP_EXPORT_H
#define  _ISP_EXPORT_H
#include "../../Tool_Common/RsDataType.h"
#include "../../Tool_Common/RsCommon/ErrorDefine.h"
#include "../../CpComm/Comm_Export/CpCommExport.h"
#include "../../Tool_Common/CpArgDefine.h"

typedef STRUCT_ENUM_ERROR_TYPE(*func_rsIspFlash)(STRUCT_CP_ISP_COMMAND_SETTING &stCmdSetting);
typedef void(*func_rsSetCommInterface)(CCpRsComm *pRsComm);

class CCpIsp
{
public:
    CCpIsp();
    virtual ~CCpIsp();
public:
    BOOL LoadIspDllFile(TCHAR* pcFile);
    void FreeIspDllFile();
    STRUCT_ENUM_ERROR_TYPE IspFlash(STRUCT_CP_ISP_COMMAND_SETTING &stCmdSetting);
    void SetCommInterface(CCpRsComm *pRsComm);


private:
    void * m_hHandle;
    func_rsIspFlash m_rsIspFlash;
    func_rsSetCommInterface m_rsSetCommInterface;

};



#endif
