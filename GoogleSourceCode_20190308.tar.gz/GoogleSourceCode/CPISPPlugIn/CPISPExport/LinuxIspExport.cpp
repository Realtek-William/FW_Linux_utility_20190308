#include "stdafx.h"
#include "CpIspExport.h"
#include <dlfcn.h>
#include <stdio.h>

BOOL CCpIsp::LoadIspDllFile(TCHAR* pcFile)
{
    //printf("pcFile :%s\n", pcFile);
    FreeIspDllFile();
    m_hHandle = dlopen(pcFile, RTLD_NOW);
    if(m_hHandle == NULL)
    {
        printf("dlopen - %sn", dlerror());  
        return FALSE;
    }

    m_rsIspFlash = (func_rsIspFlash)dlsym(m_hHandle, "IspFlash");
    if(m_rsIspFlash == NULL)
    {
        FreeIspDllFile();
        return FALSE;
    }

    m_rsSetCommInterface = (func_rsSetCommInterface)dlsym(m_hHandle, "SetCommInterface");
    if(m_rsSetCommInterface == NULL)
    {
        FreeIspDllFile();
        return FALSE;
    }
    
    return TRUE;
}

void CCpIsp::FreeIspDllFile()
{
    if(m_hHandle == NULL)
    {
        return;
    }
    dlclose(m_hHandle);
    m_hHandle = NULL;
}

